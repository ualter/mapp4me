(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~pages-airplane-airplane-module~pages-map-map-module~pages-setting-setting-module"],{

/***/ "./src/app/services/airplane.service.ts":
/*!**********************************************!*\
  !*** ./src/app/services/airplane.service.ts ***!
  \**********************************************/
/*! exports provided: Airliner, AirplaneCategorySize, AirplaneService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Airliner", function() { return Airliner; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AirplaneCategorySize", function() { return AirplaneCategorySize; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AirplaneService", function() { return AirplaneService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _utils_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _airplane__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./airplane */ "./src/app/services/airplane.ts");




var Airliner;
(function (Airliner) {
    Airliner["AIRBUS"] = "airbus";
    Airliner["BOEING"] = "boeing";
    Airliner["GENERAL"] = "general";
})(Airliner || (Airliner = {}));
var AirplaneCategorySize;
(function (AirplaneCategorySize) {
    AirplaneCategorySize[AirplaneCategorySize["SMALL_PLANES"] = 0] = "SMALL_PLANES";
    AirplaneCategorySize[AirplaneCategorySize["MEDIUM_JETS"] = 1] = "MEDIUM_JETS";
    AirplaneCategorySize[AirplaneCategorySize["BIG"] = 2] = "BIG";
    AirplaneCategorySize[AirplaneCategorySize["BIGGER"] = 3] = "BIGGER";
})(AirplaneCategorySize || (AirplaneCategorySize = {}));
var AirplaneService = /** @class */ (function () {
    function AirplaneService(utils) {
        this.utils = utils;
        this.airplanes = new Map();
        this.airliners = new Map();
        this.loadAirliners();
        this.loadAirplanes();
    }
    AirplaneService.prototype.loadAirliners = function () {
        this.airliners.set(Airliner.AIRBUS, Airliner.AIRBUS);
        this.airliners.set(Airliner.BOEING, Airliner.BOEING);
        this.airliners.set(Airliner.GENERAL, Airliner.GENERAL);
    };
    AirplaneService.prototype.loadAirplanes = function () {
        this.createAirbusAirplanes();
        this.createBoeingAirplanes();
        this.createGeneralAirplanes();
    };
    AirplaneService.prototype.keysAirliners = function () {
        return Array.from(this.airliners.keys());
    };
    AirplaneService.prototype.listAirliners = function () {
        return Array.from(this.airliners.values());
    };
    AirplaneService.prototype.keysAirplanes = function () {
        return Array.from(this.airplanes.keys());
    };
    AirplaneService.prototype.listAirplanes = function (airliner) {
        return Array.from(this.airplanes.values())
            .filter(function (airplane) {
            return airplane.airliner === airliner;
        });
    };
    AirplaneService.prototype.getAirplane = function (id) {
        return this.airplanes.get(id);
    };
    AirplaneService.prototype.listAllAirplanes = function () {
        return this.airplanes.values();
    };
    AirplaneService.prototype.createBoeingAirplanes = function () {
        var airplane;
        airplane = new _airplane__WEBPACK_IMPORTED_MODULE_3__["Airplane"]("b737-800-qantas");
        airplane.name = "B737-800 Qantas";
        airplane.airliner = Airliner.BOEING;
        airplane.categorySize = AirplaneCategorySize.BIG;
        airplane.icon = this.utils.PATH_IMG_AIRPLANES + Airliner.BOEING + "/airplane-" + airplane.id + ".png";
        airplane.icon_shadow = this.utils.PATH_IMG_AIRPLANES + Airliner.BOEING + "/airplane-" + airplane.id + "-shadow.png";
        this.airplanes.set(airplane.id, airplane);
        airplane = new _airplane__WEBPACK_IMPORTED_MODULE_3__["Airplane"]("b777-200");
        airplane.name = "B777-200";
        airplane.airliner = Airliner.BOEING;
        airplane.categorySize = AirplaneCategorySize.BIG;
        airplane.icon = this.utils.PATH_IMG_AIRPLANES + Airliner.BOEING + "/airplane-" + airplane.id + ".png";
        airplane.icon_shadow = this.utils.PATH_IMG_AIRPLANES + Airliner.BOEING + "/airplane-" + airplane.id + "-shadow.png";
        this.airplanes.set(airplane.id, airplane);
        airplane = new _airplane__WEBPACK_IMPORTED_MODULE_3__["Airplane"]("b777-200-jpn");
        airplane.name = "B777-200 JPN";
        airplane.airliner = Airliner.BOEING;
        airplane.categorySize = AirplaneCategorySize.BIG;
        airplane.icon = this.utils.PATH_IMG_AIRPLANES + Airliner.BOEING + "/airplane-" + airplane.id + ".png";
        airplane.icon_shadow = this.utils.PATH_IMG_AIRPLANES + Airliner.BOEING + "/airplane-" + airplane.id + "-shadow.png";
        this.airplanes.set(airplane.id, airplane);
        airplane = new _airplane__WEBPACK_IMPORTED_MODULE_3__["Airplane"]("b747-800-white");
        airplane.name = "B747-800 White";
        airplane.airliner = Airliner.BOEING;
        airplane.categorySize = AirplaneCategorySize.BIGGER;
        airplane.icon = this.utils.PATH_IMG_AIRPLANES + Airliner.BOEING + "/airplane-" + airplane.id + ".png";
        airplane.icon_shadow = this.utils.PATH_IMG_AIRPLANES + Airliner.BOEING + "/airplane-" + airplane.id + "-shadow.png";
        this.airplanes.set(airplane.id, airplane);
        airplane = new _airplane__WEBPACK_IMPORTED_MODULE_3__["Airplane"]("b747-400-united");
        airplane.name = "B747-400 United";
        airplane.airliner = Airliner.BOEING;
        airplane.categorySize = AirplaneCategorySize.BIGGER;
        airplane.icon = this.utils.PATH_IMG_AIRPLANES + Airliner.BOEING + "/airplane-" + airplane.id + ".png";
        airplane.icon_shadow = this.utils.PATH_IMG_AIRPLANES + Airliner.BOEING + "/airplane-" + airplane.id + "-shadow.png";
        this.airplanes.set(airplane.id, airplane);
    };
    AirplaneService.prototype.createGeneralAirplanes = function () {
        var airplane;
        airplane = new _airplane__WEBPACK_IMPORTED_MODULE_3__["Airplane"]("cessna-147");
        airplane.name = "Cessna 147";
        airplane.airliner = Airliner.GENERAL;
        airplane.categorySize = AirplaneCategorySize.SMALL_PLANES;
        airplane.icon = this.utils.PATH_IMG_AIRPLANES + Airliner.GENERAL + "/airplane-" + airplane.id + ".png";
        airplane.icon_shadow = this.utils.PATH_IMG_AIRPLANES + Airliner.GENERAL + "/airplane-" + airplane.id + "-shadow.png";
        this.airplanes.set(airplane.id, airplane);
    };
    AirplaneService.prototype.createAirbusAirplanes = function () {
        var airplane;
        airplane = new _airplane__WEBPACK_IMPORTED_MODULE_3__["Airplane"]("a310");
        airplane.name = "A310";
        airplane.airliner = Airliner.AIRBUS;
        airplane.categorySize = AirplaneCategorySize.BIG;
        airplane.icon = this.utils.PATH_IMG_AIRPLANES + Airliner.AIRBUS + "/airplane-" + airplane.id + ".png";
        airplane.icon_shadow = this.utils.PATH_IMG_AIRPLANES + Airliner.AIRBUS + "/airplane-" + airplane.id + "-shadow.png";
        this.airplanes.set(airplane.id, airplane);
        airplane = new _airplane__WEBPACK_IMPORTED_MODULE_3__["Airplane"]("a320");
        airplane.name = "A320";
        airplane.airliner = Airliner.AIRBUS;
        airplane.categorySize = AirplaneCategorySize.BIG;
        airplane.icon = this.utils.PATH_IMG_AIRPLANES + Airliner.AIRBUS + "/airplane-" + airplane.id + ".png";
        airplane.icon_shadow = this.utils.PATH_IMG_AIRPLANES + Airliner.AIRBUS + "/airplane-" + airplane.id + "-shadow.png";
        this.airplanes.set(airplane.id, airplane);
        airplane = new _airplane__WEBPACK_IMPORTED_MODULE_3__["Airplane"]("a330");
        airplane.name = "A330";
        airplane.airliner = Airliner.AIRBUS;
        airplane.categorySize = AirplaneCategorySize.BIG;
        airplane.icon = this.utils.PATH_IMG_AIRPLANES + Airliner.AIRBUS + "/airplane-" + airplane.id + ".png";
        airplane.icon_shadow = this.utils.PATH_IMG_AIRPLANES + Airliner.AIRBUS + "/airplane-" + airplane.id + "-shadow.png";
        this.airplanes.set(airplane.id, airplane);
        airplane = new _airplane__WEBPACK_IMPORTED_MODULE_3__["Airplane"]("a340");
        airplane.name = "A340";
        airplane.airliner = Airliner.AIRBUS;
        airplane.categorySize = AirplaneCategorySize.BIG;
        airplane.icon = this.utils.PATH_IMG_AIRPLANES + Airliner.AIRBUS + "/airplane-" + airplane.id + ".png";
        airplane.icon_shadow = this.utils.PATH_IMG_AIRPLANES + Airliner.AIRBUS + "/airplane-" + airplane.id + "-shadow.png";
        this.airplanes.set(airplane.id, airplane);
        airplane = new _airplane__WEBPACK_IMPORTED_MODULE_3__["Airplane"]("a350");
        airplane.name = "A350";
        airplane.airliner = Airliner.AIRBUS;
        airplane.categorySize = AirplaneCategorySize.BIG;
        airplane.icon = this.utils.PATH_IMG_AIRPLANES + Airliner.AIRBUS + "/airplane-" + airplane.id + ".png";
        airplane.icon_shadow = this.utils.PATH_IMG_AIRPLANES + Airliner.AIRBUS + "/airplane-" + airplane.id + "-shadow.png";
        this.airplanes.set(airplane.id, airplane);
        airplane = new _airplane__WEBPACK_IMPORTED_MODULE_3__["Airplane"]("a380");
        airplane.name = "A380";
        airplane.airliner = Airliner.AIRBUS;
        airplane.categorySize = AirplaneCategorySize.BIGGER;
        airplane.icon = this.utils.PATH_IMG_AIRPLANES + Airliner.AIRBUS + "/airplane-" + airplane.id + ".png";
        airplane.icon_shadow = this.utils.PATH_IMG_AIRPLANES + Airliner.AIRBUS + "/airplane-" + airplane.id + "-shadow.png";
        this.airplanes.set(airplane.id, airplane);
    };
    AirplaneService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_utils_service__WEBPACK_IMPORTED_MODULE_2__["UtilsService"]])
    ], AirplaneService);
    return AirplaneService;
}());



/***/ }),

/***/ "./src/app/services/airplane.ts":
/*!**************************************!*\
  !*** ./src/app/services/airplane.ts ***!
  \**************************************/
/*! exports provided: Airplane */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Airplane", function() { return Airplane; });
var PATH_IMG_AIRPLANES = "assets/imgs/airplanes/";
var Airplane = /** @class */ (function () {
    function Airplane(_id) {
        this.id = _id;
    }
    Airplane.pathImg = function () {
        return PATH_IMG_AIRPLANES;
    };
    return Airplane;
}());



/***/ }),

/***/ "./src/app/services/data.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/data.service.ts ***!
  \******************************************/
/*! exports provided: DataService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataService", function() { return DataService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _settings__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./settings */ "./src/app/services/settings.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _utils_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./utils.service */ "./src/app/services/utils.service.ts");






var DataService = /** @class */ (function () {
    function DataService(storage, utils) {
        var _this = this;
        this.storage = storage;
        this.utils = utils;
        this.settings = new _settings__WEBPACK_IMPORTED_MODULE_3__["settings"]();
        this.settings.xplaneAddress = '127.0.0.1';
        this.settings.xplanePort = '9002';
        this.settings.name = 'UALTER Desktop';
        this.settings.airplaneId = 'a320';
        this.settingsSource = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](this.settings);
        this.currentSettings = this.settingsSource.asObservable();
        // Asynchronously check database if there is already an object saved before, 
        // if found... notify the subscribers again with the new value
        this.storage.get('settings').then(function (vlr) {
            if (vlr) {
                _this.utils.trace("Load settings data from LocalStorage:" + vlr);
                _this.settings = JSON.parse(vlr);
                _this.settingsSource.next(_this.settings);
            }
        });
    }
    DataService.prototype.changeSettingsXplaneAddress = function (xplaneAddress) {
        this.settings.xplaneAddress = xplaneAddress;
    };
    DataService.prototype.changeSettingsXplanePort = function (xplanePort) {
        this.settings.xplanePort = xplanePort;
    };
    DataService.prototype.changeSettingsName = function (name) {
        this.settings.name = name;
    };
    DataService.prototype.changeSettingsAirplane = function (airplaneId) {
        this.settings.airplaneId = airplaneId;
    };
    DataService.prototype.changeFlightPlan = function (flightPlan) {
        this.settings.flightPlan = flightPlan;
    };
    DataService.prototype.notifyChangeSettingsToSubscribers = function () {
        this.settingsSource.next(this.settings);
    };
    DataService.prototype.saveSettings = function () {
        this.storage.set('settings', JSON.stringify(this.settings));
    };
    DataService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"], _utils_service__WEBPACK_IMPORTED_MODULE_5__["UtilsService"]])
    ], DataService);
    return DataService;
}());



/***/ }),

/***/ "./src/app/services/settings.ts":
/*!**************************************!*\
  !*** ./src/app/services/settings.ts ***!
  \**************************************/
/*! exports provided: settings */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "settings", function() { return settings; });
var settings = /** @class */ (function () {
    function settings() {
    }
    return settings;
}());



/***/ }),

/***/ "./src/app/services/utils.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/utils.service.ts ***!
  \*******************************************/
/*! exports provided: LogLevel, UtilsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogLevel", function() { return LogLevel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UtilsService", function() { return UtilsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _airplane__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./airplane */ "./src/app/services/airplane.ts");




var LogLevel;
(function (LogLevel) {
    LogLevel[LogLevel["TRACE"] = 0] = "TRACE";
    LogLevel[LogLevel["DEBUG"] = 1] = "DEBUG";
    LogLevel[LogLevel["INFO"] = 2] = "INFO";
    LogLevel[LogLevel["WARN"] = 3] = "WARN";
    LogLevel[LogLevel["ERROR"] = 4] = "ERROR";
    LogLevel[LogLevel["OFF"] = 5] = "OFF";
})(LogLevel || (LogLevel = {}));
var UtilsService = /** @class */ (function () {
    function UtilsService(platform) {
        this.platform = platform;
        this.PATH_IMG_AIRPLANES = _airplane__WEBPACK_IMPORTED_MODULE_3__["Airplane"].pathImg();
        this.level = LogLevel.DEBUG;
        this.monthNames = [
            "January", "February", "March",
            "April", "May", "June", "July",
            "August", "September", "October",
            "November", "December"
        ];
        this.shortMonthNames = [
            "Jan", "Feb", "Mar",
            "Apr", "May", "Jun", "Jul",
            "Aug", "Sep", "Oct",
            "Nov", "Dec"
        ];
    }
    UtilsService.prototype.formatCurrentTime = function (tm) {
        var h = tm.split(":")[0];
        var m = tm.split(":")[1];
        var s = tm.split(":")[2];
        return this.pad(h, 2) + ":" + this.pad(m, 2) + ":" + this.pad(s, 2);
    };
    UtilsService.prototype.pad = function (num, size) {
        return ('000000000' + num).substr(-size);
    };
    UtilsService.prototype.mountTimeFromSeconds = function (seconds) {
        return new Date(seconds * 1000).toISOString().substr(11, 8);
    };
    UtilsService.prototype.diffHours = function (start, end) {
        start = start.split(":");
        end = end.split(":");
        var startDate = new Date(0, 0, 0, start[0], start[1], start[2]);
        var endDate = new Date(0, 0, 0, end[0], end[1], end[2]);
        var diff = endDate.getTime() - startDate.getTime();
        var hours = Math.floor(diff / 1000 / 60 / 60);
        diff -= hours * 1000 * 60 * 60;
        var minutes = Math.floor(diff / 1000 / 60);
        diff -= minutes * 1000 * 60;
        var seconds = Math.floor(diff / 1000);
        if (hours < 0) {
            hours = hours + 24;
        }
        return (hours <= 9 ? "0" : "") + hours + ":" + (minutes <= 9 ? "0" : "") + minutes + ":" + (seconds <= 9 ? "0" : "") + seconds;
    };
    UtilsService.prototype.convertToMinutes = function (hour) {
        var hor = parseInt(hour.split(":")[0]) * 60;
        var min = parseInt(hour.split(":")[1]);
        return hor + min;
    };
    UtilsService.prototype.isOsPlatform = function () {
        return this.platform.is('ios');
    };
    UtilsService.prototype.isAndroidPlatform = function () {
        return this.platform.is('android');
    };
    UtilsService.prototype.isDesktop = function () {
        return this.platform.is('desktop');
    };
    UtilsService.prototype.isOsOrAndroidPlatform = function () {
        return this.isOsPlatform() || this.isAndroidPlatform();
    };
    UtilsService.prototype.formatDateToday = function () {
        return this.formatDate(new Date());
    };
    UtilsService.prototype.formattedHour = function () {
        var dt = new Date();
        var hor = ("0" + dt.getHours()).slice(-2);
        var min = ("0" + dt.getMinutes()).slice(-2);
        var sec = ("0" + dt.getSeconds()).slice(-2);
        return hor + ":" + min + ":" + sec;
    };
    UtilsService.prototype.formatDate = function (_date) {
        var day = _date.getDate();
        var monthIndex = _date.getMonth();
        var year = _date.getFullYear();
        return year + "/" + this.shortMonthNames[monthIndex] + "/" + day;
    };
    UtilsService.prototype.formatNumber = function (number) {
        return parseInt(number).toString().replace(/\d(?=(\d{3})+$)/g, '$&,');
    };
    UtilsService.prototype.isJsonMessage = function (_message) {
        if (/^[\],:{}\s]*$/.test(_message.replace(/\\["\\\/bfnrtu]/g, '@').
            replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').
            replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {
            return true;
        }
        return false;
    };
    UtilsService.prototype.writeLog = function (msg, logLevel, _object) {
        var logMsg = "[" +
            LogLevel[logLevel] +
            "] " +
            this.formatDateToday() +
            ": " +
            msg;
        if (_object != undefined) {
            logMsg += " ...(cont. next line)...";
        }
        console.log(logMsg);
        if (_object != undefined) {
            console.log(_object);
        }
    };
    UtilsService.prototype.trace = function (msg, _object) {
        if (this.level == LogLevel.TRACE) {
            this.writeLog(msg, LogLevel.TRACE, _object);
        }
    };
    UtilsService.prototype.debug = function (msg, _object) {
        if (this.level <= LogLevel.DEBUG) {
            this.writeLog(msg, LogLevel.DEBUG, _object);
        }
    };
    UtilsService.prototype.info = function (msg, _object) {
        if (this.level <= LogLevel.INFO) {
            this.writeLog(msg, LogLevel.INFO, _object);
        }
    };
    UtilsService.prototype.warn = function (msg, _object) {
        if (this.level <= LogLevel.WARN) {
            this.writeLog(msg, LogLevel.WARN, _object);
        }
    };
    UtilsService.prototype.error = function (msg, _object) {
        if (this.level >= LogLevel.ERROR) {
            this.writeLog(msg, LogLevel.ERROR, _object);
        }
    };
    UtilsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["Platform"]])
    ], UtilsService);
    return UtilsService;
}());



/***/ })

}]);
//# sourceMappingURL=default~pages-airplane-airplane-module~pages-map-map-module~pages-setting-setting-module.js.map