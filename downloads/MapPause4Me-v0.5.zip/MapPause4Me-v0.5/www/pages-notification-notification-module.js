(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-notification-notification-module"],{

/***/ "./src/app/pages/notification/notification.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/notification/notification.module.ts ***!
  \***********************************************************/
/*! exports provided: NotificationPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationPageModule", function() { return NotificationPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _notification_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./notification.page */ "./src/app/pages/notification/notification.page.ts");







var routes = [
    {
        path: '',
        component: _notification_page__WEBPACK_IMPORTED_MODULE_6__["NotificationPage"]
    }
];
var NotificationPageModule = /** @class */ (function () {
    function NotificationPageModule() {
    }
    NotificationPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_notification_page__WEBPACK_IMPORTED_MODULE_6__["NotificationPage"]]
        })
    ], NotificationPageModule);
    return NotificationPageModule;
}());



/***/ }),

/***/ "./src/app/pages/notification/notification.page.html":
/*!***********************************************************!*\
  !*** ./src/app/pages/notification/notification.page.html ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>Notifications</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content id=\"pageContent\" class=\"background\">\n    <div class=\"page-config\">\n        <ion-list>\n            <ion-item-group>\n\n                <ion-list-header class=\"listHeader\">\n                  <ion-grid class=\"headerSection\">\n                    <ion-row class=\"vertical-align-content\">\n                      <ion-col>\n                          <ion-label>\n                              <ion-thumbnail class=\"ion-thumbnailSize\"><img src=\"assets/imgs/heading.png\" class=\"imgThumbnailSize\" style=\"width:80px;height:80px;margin-right: 10px;\" ></ion-thumbnail>\n                          </ion-label>\n                      </ion-col>\n                      <ion-col>\n                          <ion-label style='font-weight:bolder;'>NAVAIDs</ion-label>\n                      </ion-col>\n                    </ion-row>\n                  </ion-grid>\n                </ion-list-header>\n\n                <!-- Lines of Alert, sequenced: Airport, VOR, NDB, FIX and DME -->\n                <ion-item lines=\"full\" *ngFor=\"let line of alertLines; let i = index\">\n                  <ion-grid class=\"navaidsContainer\">\n                    <ion-row class=\"vertical-align-content\" [ngClass]=\"!line.userSelected ? 'rowHeaderDetailsUnvisible' : 'rowHeaderDetailsVisible'\"> \n                      <ion-col>\n                          {{line.id}}\n                      </ion-col>\n                      <ion-col  offset=\"6\">\n                          <ion-toggle [(ngModel)]=\"line.userSelected\" disabled=\"true\"></ion-toggle>\n                      </ion-col>\n                    </ion-row>\n                    <ion-row class=\"vertical-align-content padding-bottom-firstline\" [ngClass]=\"!line.userSelected ? 'rowDetailsUnvisible' : 'rowDetailsVisible'\">\n                      <ion-col>\n                          <i class=\"fas fa-check-circle\" style=\"color:green;\" [hidden]=\"!line.userSelected\"></i><span [hidden]=\"!line.userSelected\">&nbsp;</span>\n                          <span class=\"labelValue\">{{line.navaId}}</span>&nbsp;\n                          <span class=\"labelValue\">{{line.distance}}nm</span>&nbsp;\n                          <span style=\"font-size:16px;font-weight: bold\"><i class=\"fas fa-less-than-equal\"></i></span>&nbsp;\n                          <span class=\"labelValue\">{{line.userDistance}}nm</span>\n                      </ion-col>\n                    </ion-row>\n                    <ion-row class=\"vertical-align-content padding-bottom-middleline\" style=\"padding-top: 5px;\" [ngClass]=\"!line.userSelected ? 'rowDetailsUnvisible' : 'rowDetailsVisible'\">\n                      <ion-col>\n                          <span><i class=\"fas fa-pause\"></i></span>&nbsp;\n                          <span class=\"labelValueCurrentNotification\">Estimated</span>&nbsp;\n                          <span class=\"labelValue\">{{line.estimatedPause}}</span>&nbsp;\n                      </ion-col>\n                    </ion-row>\n                    <ion-row class=\"vertical-align-content padding-bottom-middleline\" [ngClass]=\"!line.userSelected ? 'rowDetailsUnvisible' : 'rowDetailsVisible'\">\n                      <ion-col>\n                        <span id=\"{{'bellTimePause_' + i}}\"><i class=\"fas fa-bell-slash\"></i></span>&nbsp;\n                        <span class=\"labelValueCurrentNotification\">Alert</span>&nbsp;\n                        <ion-datetime id=\"minSecPicker\" \n                                      display-format=\"mm:ss\" \n                                      [(ngModel)]=\"line.timeToPause\" \n                                      style=\"display: inline-flex; margin:-3px 0px 0px -10px;font-weight: bold\"\n                                      [minuteValues]=\"minuteValues\" \n                                      (ionChange)=\"minuteSecondChanged(i)\"></ion-datetime>&nbsp;{{line.units}}\n                        <span class=\"labelValueCurrentNotification\">before</span>&nbsp;\n                      </ion-col>\n                    </ion-row>\n                    <ion-row class=\"vertical-align-content padding-bottom-lastline\" [ngClass]=\"!line.userSelected ? 'rowDetailsUnvisible' : 'rowDetailsVisible'\">\n                        <ion-col>\n                          <span id=\"{{'bellDistancePause_' + i}}\"><i class=\"fas fa-bell-slash\"></i></span>&nbsp;\n                          <span class=\"labelValueCurrentNotification\">Alert</span>&nbsp;\n                          <span class=\"labelValueCurrent\" (click)=\"openPicker(i)\" style=\"margin:0px 20px 0px 18px;\" >{{line.nmToPause | number:'2.0'}}</span>&nbsp;nm&nbsp;\n                          <span class=\"labelValueCurrentNotification\">before</span>&nbsp;\n                        </ion-col>\n                      </ion-row>\n                  </ion-grid>\n                </ion-item>\n\n                <ion-item>\n                  <ion-button (click)=\"onClick()\">List Notifications</ion-button>\n                </ion-item>\n\n            </ion-item-group>\n        </ion-list>      \n    </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/notification/notification.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/pages/notification/notification.page.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@media (min-width: 650px) {\n  .page-config {\n    margin-left: auto;\n    margin-right: auto;\n    width: var(--pauseforme-width-max);\n    box-shadow: 3px 3px 6px 4px rgba(50, 50, 50, 0.6); }\n  .navaidsContainer {\n    padding: 0px 30px 0 30px; }\n  .headerSection {\n    padding-left: 30px;\n    padding-right: 30px; }\n  ion-content.background {\n    --background: var(--pauseform-background); } }\n\n@media (min-width: 480px) and (max-width: 649px) {\n  ion-content.background {\n    --background: var(--pauseform-background); } }\n\nion-item-divider.config {\n  padding-bottom: 3px;\n  background-color: #F2F2F2; }\n\nion-list-header.padding {\n  padding-top: 20px;\n  padding-bottom: 20px; }\n\n.rowHeaderDetailsVisible {\n  margin-bottom: -10px; }\n\n.rowDetailsUnvisible {\n  display: none !important; }\n\n.rowDetailsVisible {\n  display: block !important; }\n\nion-row.padding-bottom-middleline {\n  padding-bottom: 7px; }\n\nion-row.padding-bottom-lastline {\n  padding-bottom: 12px; }\n\nion-row.padding-bottom-firstline {\n  padding-bottom: 7px;\n  padding-top: 15px; }\n\n.labelValueCurrentNotification {\n  color: black; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbm90aWZpY2F0aW9uL0Q6XFxEZXZlbG9wZXJcXGNvZGVcXGlvbmljXFx4cC1wYXVzZWZvcm1lLXYxL3NyY1xcYXBwXFxwYWdlc1xcbm90aWZpY2F0aW9uXFxub3RpZmljYXRpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0k7SUFDSSxpQkFBZ0I7SUFDaEIsa0JBQWlCO0lBQ2pCLGtDQUFrQztJQUdsQyxpREFBMEQsRUFBQTtFQUU5RDtJQUNJLHdCQUF3QixFQUFBO0VBRTVCO0lBQ0ksa0JBQWtCO0lBQ2xCLG1CQUFtQixFQUFBO0VBRXZCO0lBQ0kseUNBQWEsRUFBQSxFQUNoQjs7QUFHTDtFQUNJO0lBQ0kseUNBQWEsRUFBQSxFQUNoQjs7QUFJTDtFQUNJLG1CQUFtQjtFQUNuQix5QkFBeUIsRUFBQTs7QUFFN0I7RUFDSSxpQkFBaUI7RUFDakIsb0JBQW9CLEVBQUE7O0FBTXhCO0VBQ0ksb0JBQW9CLEVBQUE7O0FBRXhCO0VBQ0ksd0JBQXdCLEVBQUE7O0FBRTVCO0VBQ0kseUJBQXlCLEVBQUE7O0FBRzdCO0VBQ0ksbUJBQW1CLEVBQUE7O0FBRXZCO0VBQ0ksb0JBQW9CLEVBQUE7O0FBRXhCO0VBQ0ksbUJBQW1CO0VBQ25CLGlCQUFpQixFQUFBOztBQUdyQjtFQUNJLFlBQVksRUFBQSIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL25vdGlmaWNhdGlvbi9ub3RpZmljYXRpb24ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQG1lZGlhIChtaW4td2lkdGg6NjUwcHgpIHsgLy8gdGhpcyBydWxlIHdpbGwgb25seSB0cmlnZ2VyIGlmIHNjcmVlbiB3aWR0aCBpcyBhYm92ZSBYcHgsXHJcbiAgICAucGFnZS1jb25maWcge1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OmF1dG87XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OmF1dG87XHJcbiAgICAgICAgd2lkdGg6IHZhcigtLXBhdXNlZm9ybWUtd2lkdGgtbWF4KTtcclxuICAgICAgICAtbW96LWJveC1zaGFkb3c6ICAgIDNweCAzcHggNnB4IDRweCByZ2JhKDUwLCA1MCwgNTAsIDAuNjApO1xyXG4gICAgICAgIC13ZWJraXQtYm94LXNoYWRvdzogM3B4IDNweCA2cHggNHB4IHJnYmEoNTAsIDUwLCA1MCwgMC42MCk7XHJcbiAgICAgICAgYm94LXNoYWRvdzogICAgICAgICAzcHggM3B4IDZweCA0cHggcmdiYSg1MCwgNTAsIDUwLCAwLjYwKTtcclxuICAgIH1cclxuICAgIC5uYXZhaWRzQ29udGFpbmVyIHtcclxuICAgICAgICBwYWRkaW5nOiAwcHggMzBweCAwIDMwcHg7XHJcbiAgICB9XHJcbiAgICAuaGVhZGVyU2VjdGlvbiB7XHJcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAzMHB4O1xyXG4gICAgICAgIHBhZGRpbmctcmlnaHQ6IDMwcHg7XHJcbiAgICB9XHJcbiAgICBpb24tY29udGVudC5iYWNrZ3JvdW5kIHtcclxuICAgICAgICAtLWJhY2tncm91bmQ6IHZhcigtLXBhdXNlZm9ybS1iYWNrZ3JvdW5kKTtcclxuICAgIH1cclxufVxyXG5cclxuQG1lZGlhIChtaW4td2lkdGg6NDgwcHgpIGFuZCAobWF4LXdpZHRoOjY0OXB4KSB7IFxyXG4gICAgaW9uLWNvbnRlbnQuYmFja2dyb3VuZCB7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1wYXVzZWZvcm0tYmFja2dyb3VuZCk7XHJcbiAgICB9XHJcbn1cclxuXHJcblxyXG5pb24taXRlbS1kaXZpZGVyLmNvbmZpZyB7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogM3B4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0YyRjJGMjtcclxufVxyXG5pb24tbGlzdC1oZWFkZXIucGFkZGluZyB7XHJcbiAgICBwYWRkaW5nLXRvcDogMjBweDtcclxuICAgIHBhZGRpbmctYm90dG9tOiAyMHB4O1xyXG59XHJcblxyXG4ucm93SGVhZGVyRGV0YWlsc1VudmlzaWJsZSB7XHJcbiAgICAvL1xyXG59XHJcbi5yb3dIZWFkZXJEZXRhaWxzVmlzaWJsZSB7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAtMTBweDtcclxufVxyXG4ucm93RGV0YWlsc1VudmlzaWJsZSB7XHJcbiAgICBkaXNwbGF5OiBub25lICFpbXBvcnRhbnQ7XHJcbn1cclxuLnJvd0RldGFpbHNWaXNpYmxlIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1yb3cucGFkZGluZy1ib3R0b20tbWlkZGxlbGluZSB7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogN3B4O1xyXG59XHJcbmlvbi1yb3cucGFkZGluZy1ib3R0b20tbGFzdGxpbmUge1xyXG4gICAgcGFkZGluZy1ib3R0b206IDEycHg7XHJcbn1cclxuaW9uLXJvdy5wYWRkaW5nLWJvdHRvbS1maXJzdGxpbmUge1xyXG4gICAgcGFkZGluZy1ib3R0b206IDdweDtcclxuICAgIHBhZGRpbmctdG9wOiAxNXB4O1xyXG59XHJcblxyXG4ubGFiZWxWYWx1ZUN1cnJlbnROb3RpZmljYXRpb24ge1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG4gfSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/notification/notification.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/notification/notification.page.ts ***!
  \*********************************************************/
/*! exports provided: NotificationPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationPage", function() { return NotificationPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/local-notifications/ngx */ "./node_modules/@ionic-native/local-notifications/ngx/index.js");
/* harmony import */ var src_app_services_xp_websocket_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/xp-websocket.service */ "./src/app/services/xp-websocket.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _services_map_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/map.service */ "./src/app/services/map.service.ts");
/* harmony import */ var _services_notification_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../services/notification.service */ "./src/app/services/notification.service.ts");








var NotificationPage = /** @class */ (function () {
    function NotificationPage(platform, pickerCtrl, localNotifications, utils, xpWsSocket, mapService, notificationService) {
        var _this = this;
        this.platform = platform;
        this.pickerCtrl = pickerCtrl;
        this.localNotifications = localNotifications;
        this.utils = utils;
        this.xpWsSocket = xpWsSocket;
        this.mapService = mapService;
        this.notificationService = notificationService;
        this.optionsNm = [];
        this.minuteValues = "0,1,2,3,4,5,6,7,8,9,10,15,20,25,30,35,40,45,50,55";
        this.alertLines = [];
        this.scheduled = [];
        for (var i = 0; i <= 100; i++) {
            this.optionsNm.push({ text: '' + i, value: i });
        }
        if (platform.is("iphone")) {
        }
        this.alertLines = [
            {
                "index": 0,
                "alertTimeId": 1,
                "alertDistanceId": 11,
                "id": "Airport",
                "userSelected": false,
                "navaId": "LEBL",
                "distance": 999,
                "userDistance": 0,
                "estimatedPause": "99:99:99",
                "timeToPause": "00:00:00",
                "units": "min",
                "nmToPause": 0,
                "alertTimeSet": false,
                "alertDistanceSet": false,
                "alertTimeSchedule": false,
                "alertDistanceSchedule": false,
                "alertTimeTriggered": false,
                "alertDistanceTriggered": false
            },
            {
                "index": 1,
                "alertTimeId": 2,
                "alertDistanceId": 12,
                "id": "VOR",
                "userSelected": false,
                "navaId": "SLL",
                "distance": 999,
                "userDistance": 0,
                "estimatedPause": "99:99:99",
                "timeToPause": "00:00:00",
                "units": "min",
                "nmToPause": 0,
                "alertTimeSet": false,
                "alertDistanceSet": false,
                "alertTimeSchedule": false,
                "alertDistanceSchedule": false,
                "alertTimeTriggered": false,
                "alertDistanceTriggered": false
            },
            {
                "index": 2,
                "alertTimeId": 3,
                "alertDistanceId": 13,
                "id": "NDB",
                "userSelected": false,
                "navaId": "TOLUS",
                "distance": 999,
                "userDistance": 0,
                "estimatedPause": "99:99:99",
                "timeToPause": "00:00:00",
                "units": "min",
                "nmToPause": 0,
                "alertTimeSet": false,
                "alertDistanceSet": false,
                "alertTimeSchedule": false,
                "alertDistanceSchedule": false,
                "alertTimeTriggered": false,
                "alertDistanceTriggered": false
            },
            {
                "index": 3,
                "alertTimeId": 4,
                "alertDistanceId": 14,
                "id": "Fix",
                "userSelected": false,
                "navaId": "VEKKO",
                "distance": 999,
                "userDistance": 0,
                "estimatedPause": "99:99:99",
                "timeToPause": "00:00:00",
                "units": "min",
                "nmToPause": 0,
                "alertTimeSet": false,
                "alertDistanceSet": false,
                "alertTimeSchedule": false,
                "alertDistanceSchedule": false,
                "alertTimeTriggered": false,
                "alertDistanceTriggered": false
            },
            {
                "index": 4,
                "alertTimeId": 5,
                "alertDistanceId": 15,
                "id": "DME",
                "userSelected": false,
                "navaId": "SLE",
                "distance": 999,
                "userDistance": 0,
                "estimatedPause": "99:99:99",
                "timeToPause": "00:00:00",
                "units": "min",
                "nmToPause": 0,
                "alertTimeSet": false,
                "alertDistanceSet": false,
                "alertTimeSchedule": false,
                "alertDistanceSchedule": false,
                "alertTimeTriggered": false,
                "alertDistanceTriggered": false
            }
        ];
        // Load the persitent configuration notifications (For exemple: Alarm must be set or not)
        this.notifications = this.notificationService.getNotifications();
        for (var i = 0; i < 5; i++) {
            this.alertLines[i].alertTimeId = this.notifications.notification[i].alertTimeId;
            this.alertLines[i].alertDistanceId = this.notifications.notification[i].alertDistanceId;
            this.alertLines[i].id = this.notifications.notification[i].id;
            this.alertLines[i].timeToPause = this.notifications.notification[i].timeToPause;
            this.alertLines[i].nmToPause = this.notifications.notification[i].nmToPause;
            this.alertLines[i].alertTimeSet = this.notifications.notification[i].alertTimeSet;
            this.alertLines[i].alertDistanceSet = this.notifications.notification[i].alertDistanceSet;
            this.alertLines[i].alertTimeSchedule = this.notifications.notification[i].alertTimeSchedule;
            this.alertLines[i].alertDistanceSchedule = this.notifications.notification[i].alertDistanceSchedule;
            this.alertLines[i].alertTimeTriggered = this.notifications.notification[i].alertTimeTriggered;
            this.alertLines[i].alertDistanceTriggered = this.notifications.notification[i].alertDistanceTriggered;
            this.alertLines[i].units = this.defineUnits(this.notifications.notification[i].timeToPause);
        }
        this.platform.ready().then(function () {
            // Local Notifications Events
            // Events Supported: add, trigger, click, clear, cancel, update, clearall and cancelall
            _this.localNotifications.on('click').subscribe(function (res) {
                console.log("CLICK");
                console.log(res.data);
                var dataMsg = res.data.mydata;
                if (dataMsg.typeAlert == _services_notification_service__WEBPACK_IMPORTED_MODULE_7__["AlertType"].TIME) {
                    _this.alertLines[dataMsg.index].timeToPause = "00:00:00";
                    _this.cancelTimeAlert(dataMsg.id, dataMsg.index);
                }
                else if (dataMsg.typeAlert == _services_notification_service__WEBPACK_IMPORTED_MODULE_7__["AlertType"].DISTANCE) {
                    _this.alertLines[dataMsg.index].nmToPause = 0;
                    _this.cancelDistanceAlert(dataMsg.id, dataMsg.index);
                }
            });
            _this.localNotifications.on('trigger').subscribe(function (res) {
                console.log("TRIGGER");
                console.log(res.data);
                var dataMsg = res.data.mydata;
                if (dataMsg.typeAlert == _services_notification_service__WEBPACK_IMPORTED_MODULE_7__["AlertType"].TIME) {
                    _this.alertLines[dataMsg.index].alertTimeTriggered = true;
                    _this.notifications.notification[dataMsg.index].alertTimeTriggered = true;
                    _this.changeBellStyleToTriggeredState("bellTimePause_" + dataMsg.index);
                }
                else if (dataMsg.typeAlert == _services_notification_service__WEBPACK_IMPORTED_MODULE_7__["AlertType"].DISTANCE) {
                    _this.alertLines[dataMsg.index].alertDistanceTriggered = true;
                    _this.notifications.notification[dataMsg.index].alertDistanceTriggered = true;
                    _this.changeBellStyleToTriggeredState("bellDistancePause_" + dataMsg.index);
                }
                _this.notificationService.saveNotifications();
            });
        });
        this.subscription = this.xpWsSocket.messageStream().subscribe(function (json) {
            var json = JSON.parse(json);
            if (json.airplane) {
                _this.alertLines[0].userSelected = json.airplane.pauseforme.navaid.config.selected.airport;
                _this.alertLines[0].navaId = json.airplane.pauseforme.navaid.config.id.airport;
                _this.alertLines[0].distance = json.airplane.pauseforme.navaid.config.distance.airport;
                _this.alertLines[0].userDistance = json.airplane.pauseforme.navaid.userAirportDistance;
                _this.alertLines[0].estimatedPause = _this.mapService.etaPauseByNavaIdAirport;
                _this.alertLines[1].userSelected = json.airplane.pauseforme.navaid.config.selected.vor;
                _this.alertLines[1].navaId = json.airplane.pauseforme.navaid.config.id.vor;
                _this.alertLines[1].distance = json.airplane.pauseforme.navaid.config.distance.vor;
                _this.alertLines[1].userDistance = json.airplane.pauseforme.navaid.userVORDistance;
                _this.alertLines[1].estimatedPause = _this.mapService.etaPauseByNavaIdVor;
                _this.alertLines[2].userSelected = json.airplane.pauseforme.navaid.config.selected.ndb;
                _this.alertLines[2].navaId = json.airplane.pauseforme.navaid.config.id.ndb;
                _this.alertLines[2].distance = json.airplane.pauseforme.navaid.config.distance.ndb;
                _this.alertLines[2].userDistance = json.airplane.pauseforme.navaid.userNDBDistance;
                _this.alertLines[2].estimatedPause = _this.mapService.etaPauseByNavaIdNdb;
                _this.alertLines[3].userSelected = json.airplane.pauseforme.navaid.config.selected.fix;
                _this.alertLines[3].navaId = json.airplane.pauseforme.navaid.config.id.fix;
                _this.alertLines[3].distance = json.airplane.pauseforme.navaid.config.distance.fix;
                _this.alertLines[3].userDistance = json.airplane.pauseforme.navaid.userFixDistance;
                _this.alertLines[3].estimatedPause = _this.mapService.etaPauseByNavaIdFix;
                _this.alertLines[4].userSelected = json.airplane.pauseforme.navaid.config.selected.dme;
                _this.alertLines[4].navaId = json.airplane.pauseforme.navaid.config.id.dme;
                _this.alertLines[4].distance = json.airplane.pauseforme.navaid.config.distance.dme;
                _this.alertLines[4].userDistance = json.airplane.pauseforme.navaid.userDMEDistance;
                _this.alertLines[4].estimatedPause = _this.mapService.etaPauseByNavaIdDme;
            }
        }, function (error) {
            _this.utils.error('Oops', error);
        });
    }
    NotificationPage.prototype.cancelDistanceAlert = function (id, index) {
        var idAlertDist = parseInt(id);
        console.log("Canceled Distance Alert for " + idAlertDist);
        this.localNotifications.cancel(idAlertDist);
        this.alertLines[index].alertDistanceSet = false;
        this.alertLines[index].alertDistanceSchedule = false;
        this.notifications.notification[index].nmToPause = 0;
        this.notifications.notification[index].alertDistanceSet = false;
        this.notifications.notification[index].alertDistanceSchedule = false;
        this.notifications.notification[index].alertDistanceTriggered = false;
        this.notificationService.saveNotifications();
        this.changeBellStyle("bellDistancePause_" + index, false);
    };
    NotificationPage.prototype.cancelTimeAlert = function (id, index) {
        console.log("Canceled Time Alert for " + id);
        this.localNotifications.cancel(id);
        this.alertLines[index].alertTimeSet = false;
        this.alertLines[index].alertTimeSchedule = false;
        this.notifications.notification[index].timeToPause = "00:00:00";
        this.notifications.notification[index].alertTimeSet = false;
        this.notifications.notification[index].alertTimeSchedule = false;
        this.notifications.notification[index].alertTimeTriggered = false;
        this.notificationService.saveNotifications();
        this.changeBellStyle("bellTimePause_" + index, false);
    };
    NotificationPage.prototype.ngAfterViewInit = function () {
        for (var i = 0; i < 5; i++) {
            if (this.alertLines[i].alertTimeSchedule) {
                this.changeBellStyle("bellTimePause_" + i, true);
            }
            if (this.alertLines[i].alertDistanceSchedule) {
                this.changeBellStyle("bellDistancePause_" + i, true);
            }
            if (this.alertLines[i].alertTimeTriggered) {
                this.changeBellStyleToTriggeredState("bellTimePause_" + i);
            }
            if (this.alertLines[i].alertDistanceTriggered) {
                this.changeBellStyleToTriggeredState("bellDistancePause_" + i);
            }
        }
    };
    NotificationPage.prototype.ngOnInit = function () {
    };
    NotificationPage.prototype.ngOnDestroy = function () {
        this.subscription.unsubscribe();
    };
    NotificationPage.prototype.defineUnits = function (timeToPause) {
        var units = "xx";
        var min = parseInt(timeToPause.split(":")[1]);
        var sec = parseInt(timeToPause.split(":")[2]);
        if (min == 0) {
            units = "sec";
        }
        else if (min == 1) {
            units = "min";
        }
        else {
            units = "min";
        }
        return units;
    };
    NotificationPage.prototype.minuteSecondChanged = function (index) {
        var line = this.alertLines[index];
        var min = parseInt(line.timeToPause.split(":")[1]);
        var sec = parseInt(line.timeToPause.split(":")[2]);
        line.units = this.defineUnits(line.timeToPause);
        // Remove the previous and create the new with the new values
        this.cancelTimeAlert(line.alertTimeId, index);
        if (min > 0 || sec > 0) {
            this.changeBellStyle("bellTimePause_" + index, true);
            this.notifications.notification[index].timeToPause = this.alertLines[index].timeToPause;
            this.notifications.notification[index].alertTimeSchedule = true;
            this.notificationService.saveNotifications();
        }
    };
    NotificationPage.prototype.calculateTimeScheduleInSeconds = function (line) {
        var minutes = parseInt(line.timeToPause.split(":")[1]);
        var seconds = parseInt(line.timeToPause.split(":")[2]);
        var totalSec = (minutes * 60) + seconds;
        return totalSec;
    };
    NotificationPage.prototype.getAll = function () {
        var _this = this;
        this.localNotifications.getAll().then(function (res) {
            _this.scheduled = res;
        });
    };
    NotificationPage.prototype.onClick = function () {
        this.getAll();
    };
    NotificationPage.prototype.openPicker = function (index) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var picker;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.pickerCtrl.create({
                            buttons: [
                                { text: 'Cancel' },
                                { text: 'Done', handler: function (e) { _this.changeNauticalMilesValue(e, index); } }
                            ],
                            columns: [
                                {
                                    name: 'NauticalMiles',
                                    options: this.optionsNm
                                }
                            ]
                        })];
                    case 1:
                        picker = _a.sent();
                        return [4 /*yield*/, picker.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    NotificationPage.prototype.changeNauticalMilesValue = function (e, index) {
        var newValue = e.NauticalMiles.value;
        var oldValue = this.alertLines[index].nmToPause;
        this.alertLines[index].nmToPause = newValue;
        // Clear the Alert
        if (parseInt(newValue) == 0 && parseInt(oldValue) > 0) {
            this.cancelDistanceAlert(this.alertLines[index].alertDistanceId, index);
        }
        else 
        // Change the alert / Erase the Previous and Let the new one be created when receive data from X-Plane and detect the target distance notification
        if (parseInt(newValue) > 0 && (parseInt(newValue) != parseInt(oldValue))) {
            this.cancelDistanceAlert(this.alertLines[index].alertDistanceId, index);
            this.changeBellStyle("bellDistancePause_" + index, true); // Turn the "future" local notification ON
            // Save the configuration
            this.notifications.notification[index].nmToPause = this.alertLines[index].nmToPause;
            this.notifications.notification[index].alertDistanceSchedule = true;
            this.notificationService.saveNotifications();
        }
    };
    NotificationPage.prototype.createDistanceMessageAlert = function (line) {
        return 'We are close to the distance of '
            + line.nmToPause + ' nm to '
            + line.navaId + " ("
            + line.distance + "nm <= "
            + line.userDistance + "nm)";
    };
    NotificationPage.prototype.changeBellStyle = function (idElement, stateOn) {
        var bellElement = document.getElementById(idElement).firstElementChild;
        if (stateOn) {
            bellElement.setAttribute("class", "fas fa-bell");
            bellElement.setAttribute("style", "color:green;");
        }
        else {
            bellElement.setAttribute("class", "fas fa-bell-slash");
            bellElement.setAttribute("style", "color:black;");
        }
    };
    NotificationPage.prototype.changeBellStyleToTriggeredState = function (idElement) {
        var bellElement = document.getElementById(idElement).firstElementChild;
        bellElement.setAttribute("class", "fas fa-bell");
        bellElement.setAttribute("style", "color:lightgray;");
    };
    NotificationPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-notification',
            template: __webpack_require__(/*! ./notification.page.html */ "./src/app/pages/notification/notification.page.html"),
            styles: [__webpack_require__(/*! ./notification.page.scss */ "./src/app/pages/notification/notification.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PickerController"],
            _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_3__["LocalNotifications"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_5__["UtilsService"],
            src_app_services_xp_websocket_service__WEBPACK_IMPORTED_MODULE_4__["XpWebSocketService"],
            _services_map_service__WEBPACK_IMPORTED_MODULE_6__["MapService"],
            _services_notification_service__WEBPACK_IMPORTED_MODULE_7__["NotificationService"]])
    ], NotificationPage);
    return NotificationPage;
}());



/***/ }),

/***/ "./src/app/services/airplane.ts":
/*!**************************************!*\
  !*** ./src/app/services/airplane.ts ***!
  \**************************************/
/*! exports provided: Airplane */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Airplane", function() { return Airplane; });
var PATH_IMG_AIRPLANES = "assets/imgs/airplanes/";
var Airplane = /** @class */ (function () {
    function Airplane(_id) {
        this.id = _id;
    }
    Airplane.pathImg = function () {
        return PATH_IMG_AIRPLANES;
    };
    return Airplane;
}());



/***/ }),

/***/ "./src/app/services/utils.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/utils.service.ts ***!
  \*******************************************/
/*! exports provided: LogLevel, UtilsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogLevel", function() { return LogLevel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UtilsService", function() { return UtilsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _airplane__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./airplane */ "./src/app/services/airplane.ts");




var LogLevel;
(function (LogLevel) {
    LogLevel[LogLevel["TRACE"] = 0] = "TRACE";
    LogLevel[LogLevel["DEBUG"] = 1] = "DEBUG";
    LogLevel[LogLevel["INFO"] = 2] = "INFO";
    LogLevel[LogLevel["WARN"] = 3] = "WARN";
    LogLevel[LogLevel["ERROR"] = 4] = "ERROR";
    LogLevel[LogLevel["OFF"] = 5] = "OFF";
})(LogLevel || (LogLevel = {}));
var UtilsService = /** @class */ (function () {
    function UtilsService(platform) {
        this.platform = platform;
        this.PATH_IMG_AIRPLANES = _airplane__WEBPACK_IMPORTED_MODULE_3__["Airplane"].pathImg();
        this.level = LogLevel.DEBUG;
        this.monthNames = [
            "January", "February", "March",
            "April", "May", "June", "July",
            "August", "September", "October",
            "November", "December"
        ];
        this.shortMonthNames = [
            "Jan", "Feb", "Mar",
            "Apr", "May", "Jun", "Jul",
            "Aug", "Sep", "Oct",
            "Nov", "Dec"
        ];
    }
    UtilsService.prototype.formatCurrentTime = function (tm) {
        var h = tm.split(":")[0];
        var m = tm.split(":")[1];
        var s = tm.split(":")[2];
        return this.pad(h, 2) + ":" + this.pad(m, 2) + ":" + this.pad(s, 2);
    };
    UtilsService.prototype.pad = function (num, size) {
        return ('000000000' + num).substr(-size);
    };
    UtilsService.prototype.mountTimeFromSeconds = function (seconds) {
        return new Date(seconds * 1000).toISOString().substr(11, 8);
    };
    UtilsService.prototype.diffHours = function (start, end) {
        start = start.split(":");
        end = end.split(":");
        var startDate = new Date(0, 0, 0, start[0], start[1], start[2]);
        var endDate = new Date(0, 0, 0, end[0], end[1], end[2]);
        var diff = endDate.getTime() - startDate.getTime();
        var hours = Math.floor(diff / 1000 / 60 / 60);
        diff -= hours * 1000 * 60 * 60;
        var minutes = Math.floor(diff / 1000 / 60);
        diff -= minutes * 1000 * 60;
        var seconds = Math.floor(diff / 1000);
        if (hours < 0) {
            hours = hours + 24;
        }
        return (hours <= 9 ? "0" : "") + hours + ":" + (minutes <= 9 ? "0" : "") + minutes + ":" + (seconds <= 9 ? "0" : "") + seconds;
    };
    UtilsService.prototype.convertToMinutes = function (hour) {
        var hor = parseInt(hour.split(":")[0]) * 60;
        var min = parseInt(hour.split(":")[1]);
        return hor + min;
    };
    UtilsService.prototype.isOsPlatform = function () {
        return this.platform.is('ios');
    };
    UtilsService.prototype.isAndroidPlatform = function () {
        return this.platform.is('android');
    };
    UtilsService.prototype.isDesktop = function () {
        return this.platform.is('desktop');
    };
    UtilsService.prototype.isOsOrAndroidPlatform = function () {
        return this.isOsPlatform() || this.isAndroidPlatform();
    };
    UtilsService.prototype.formatDateToday = function () {
        return this.formatDate(new Date());
    };
    UtilsService.prototype.formattedHour = function () {
        var dt = new Date();
        var hor = ("0" + dt.getHours()).slice(-2);
        var min = ("0" + dt.getMinutes()).slice(-2);
        var sec = ("0" + dt.getSeconds()).slice(-2);
        return hor + ":" + min + ":" + sec;
    };
    UtilsService.prototype.formatDate = function (_date) {
        var day = _date.getDate();
        var monthIndex = _date.getMonth();
        var year = _date.getFullYear();
        return year + "/" + this.shortMonthNames[monthIndex] + "/" + day;
    };
    UtilsService.prototype.formatNumber = function (number) {
        return parseInt(number).toString().replace(/\d(?=(\d{3})+$)/g, '$&,');
    };
    UtilsService.prototype.isJsonMessage = function (_message) {
        if (/^[\],:{}\s]*$/.test(_message.replace(/\\["\\\/bfnrtu]/g, '@').
            replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').
            replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {
            return true;
        }
        return false;
    };
    UtilsService.prototype.writeLog = function (msg, logLevel, _object) {
        var logMsg = "[" +
            LogLevel[logLevel] +
            "] " +
            this.formatDateToday() +
            ": " +
            msg;
        if (_object != undefined) {
            logMsg += " ...(cont. next line)...";
        }
        console.log(logMsg);
        if (_object != undefined) {
            console.log(_object);
        }
    };
    UtilsService.prototype.trace = function (msg, _object) {
        if (this.level == LogLevel.TRACE) {
            this.writeLog(msg, LogLevel.TRACE, _object);
        }
    };
    UtilsService.prototype.debug = function (msg, _object) {
        if (this.level <= LogLevel.DEBUG) {
            this.writeLog(msg, LogLevel.DEBUG, _object);
        }
    };
    UtilsService.prototype.info = function (msg, _object) {
        if (this.level <= LogLevel.INFO) {
            this.writeLog(msg, LogLevel.INFO, _object);
        }
    };
    UtilsService.prototype.warn = function (msg, _object) {
        if (this.level <= LogLevel.WARN) {
            this.writeLog(msg, LogLevel.WARN, _object);
        }
    };
    UtilsService.prototype.error = function (msg, _object) {
        if (this.level >= LogLevel.ERROR) {
            this.writeLog(msg, LogLevel.ERROR, _object);
        }
    };
    UtilsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["Platform"]])
    ], UtilsService);
    return UtilsService;
}());



/***/ })

}]);
//# sourceMappingURL=pages-notification-notification-module.js.map