(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~pages-map-map-module~pages-notification-notification-module"],{

/***/ "./src/app/services/map.service.ts":
/*!*****************************************!*\
  !*** ./src/app/services/map.service.ts ***!
  \*****************************************/
/*! exports provided: MapService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MapService", function() { return MapService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _utils_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var DISTANCE_NM = 1852.05;
var SPEED_KTS = 0.514444444444;
var MapService = /** @class */ (function () {
    function MapService(utils) {
        this.utils = utils;
    }
    Object.defineProperty(MapService.prototype, "etaPauseByTime", {
        get: function () {
            return this._etaPauseByTime;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MapService.prototype, "etaPauseByNavaIdAirport", {
        get: function () {
            return this._etaPauseByNavaIdAirport;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MapService.prototype, "etaPauseByNavaIdVor", {
        get: function () {
            return this._etaPauseByNavaIdVor;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MapService.prototype, "etaPauseByNavaIdNdb", {
        get: function () {
            return this._etaPauseByNavaIdNdb;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MapService.prototype, "etaPauseByNavaIdFix", {
        get: function () {
            return this._etaPauseByNavaIdFix;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MapService.prototype, "etaPauseByNavaIdDme", {
        get: function () {
            return this._etaPauseByNavaIdDme;
        },
        enumerable: true,
        configurable: true
    });
    MapService.prototype.calculateETAPauseNavaIdAirport = function (airplaneGroundspeed, distanceAirport) {
        var distance = parseInt(distanceAirport);
        var etaSeconds = ((distance * DISTANCE_NM) / (airplaneGroundspeed * SPEED_KTS));
        this._etaPauseByNavaIdAirport = this.utils.mountTimeFromSeconds(etaSeconds);
    };
    MapService.prototype.calculateETAPauseNavaIdVor = function (airplaneGroundspeed, distanceVor) {
        var distance = parseInt(distanceVor);
        var etaSeconds = ((distance * DISTANCE_NM) / (airplaneGroundspeed * SPEED_KTS));
        this._etaPauseByNavaIdVor = this.utils.mountTimeFromSeconds(etaSeconds);
    };
    MapService.prototype.calculateETAPauseNavaIdFix = function (airplaneGroundspeed, distanceFix) {
        var distance = parseInt(distanceFix);
        var etaSeconds = ((distance * DISTANCE_NM) / (airplaneGroundspeed * SPEED_KTS));
        this._etaPauseByNavaIdFix = this.utils.mountTimeFromSeconds(etaSeconds);
    };
    MapService.prototype.calculateETAPauseNavaIdNdb = function (airplaneGroundspeed, distanceNdb) {
        var distance = parseInt(distanceNdb);
        var etaSeconds = ((distance * DISTANCE_NM) / (airplaneGroundspeed * SPEED_KTS));
        this._etaPauseByNavaIdNdb = this.utils.mountTimeFromSeconds(etaSeconds);
    };
    MapService.prototype.calculateETAPauseNavaIdDme = function (airplaneGroundspeed, distanceDme) {
        var distance = parseInt(distanceDme);
        var etaSeconds = ((distance * DISTANCE_NM) / (airplaneGroundspeed * SPEED_KTS));
        this._etaPauseByNavaIdDme = this.utils.mountTimeFromSeconds(etaSeconds);
    };
    MapService.prototype.calculateETAPauseTime = function (time, timePause) {
        this._etaPauseByTime = this.utils.diffHours(time, timePause);
    };
    MapService.prototype.resetETAPauseNavaIdAirport = function () {
        this._etaPauseByNavaIdAirport = null;
    };
    MapService.prototype.resetETAPauseNavaIdVor = function () {
        this._etaPauseByNavaIdVor = null;
    };
    MapService.prototype.resetETAPauseNavaIdNdb = function () {
        this._etaPauseByNavaIdNdb = null;
    };
    MapService.prototype.resetETAPauseNavaIdFix = function () {
        this._etaPauseByNavaIdFix = null;
    };
    MapService.prototype.resetETAPauseNavaIdDme = function () {
        this._etaPauseByNavaIdDme = null;
    };
    MapService.prototype.resetAllNavaids = function () {
        this.resetETAPauseNavaIdAirport();
        this.resetETAPauseNavaIdVor();
        this.resetETAPauseNavaIdFix();
        this.resetETAPauseNavaIdNdb();
        this.resetETAPauseNavaIdDme();
    };
    MapService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_utils_service__WEBPACK_IMPORTED_MODULE_1__["UtilsService"]])
    ], MapService);
    return MapService;
}());



/***/ }),

/***/ "./src/app/services/notification.service.ts":
/*!**************************************************!*\
  !*** ./src/app/services/notification.service.ts ***!
  \**************************************************/
/*! exports provided: NotificationIndex, AlertType, AlertMessage, NotificationService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationIndex", function() { return NotificationIndex; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AlertType", function() { return AlertType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AlertMessage", function() { return AlertMessage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationService", function() { return NotificationService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _map_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./map.service */ "./src/app/services/map.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _notification__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./notification */ "./src/app/services/notification.ts");
/* harmony import */ var _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/local-notifications/ngx */ "./node_modules/@ionic-native/local-notifications/ngx/index.js");







var NotificationIndex;
(function (NotificationIndex) {
    NotificationIndex[NotificationIndex["AIRPORT"] = 0] = "AIRPORT";
    NotificationIndex[NotificationIndex["VOR"] = 1] = "VOR";
    NotificationIndex[NotificationIndex["NDB"] = 2] = "NDB";
    NotificationIndex[NotificationIndex["FIX"] = 3] = "FIX";
    NotificationIndex[NotificationIndex["DME"] = 4] = "DME";
})(NotificationIndex || (NotificationIndex = {}));
;
var AlertType;
(function (AlertType) {
    AlertType[AlertType["TIME"] = 0] = "TIME";
    AlertType[AlertType["DISTANCE"] = 1] = "DISTANCE";
})(AlertType || (AlertType = {}));
var AlertMessage = /** @class */ (function () {
    function AlertMessage() {
    }
    return AlertMessage;
}());

var NotificationService = /** @class */ (function () {
    function NotificationService(storage, utils, mapService, localNotifications) {
        var _this = this;
        this.storage = storage;
        this.utils = utils;
        this.mapService = mapService;
        this.localNotifications = localNotifications;
        this.notifications = new _notification__WEBPACK_IMPORTED_MODULE_5__["notifications"]();
        this.notifications.notification = [
            {
                "index": NotificationIndex.AIRPORT,
                "alertTimeId": 1,
                "alertDistanceId": 11,
                "id": "Airport",
                "timeToPause": "00:00:00",
                "nmToPause": 0,
                "alertTimeSet": false,
                "alertDistanceSet": false,
                "alertTimeSchedule": false,
                "alertDistanceSchedule": false,
                "alertTimeTriggered": false,
                "alertDistanceTriggered": false
            },
            {
                "index": NotificationIndex.VOR,
                "alertTimeId": 2,
                "alertDistanceId": 12,
                "id": "VOR",
                "timeToPause": "00:00:00",
                "nmToPause": 0,
                "alertTimeSet": false,
                "alertDistanceSet": false,
                "alertTimeSchedule": false,
                "alertDistanceSchedule": false,
                "alertTimeTriggered": false,
                "alertDistanceTriggered": false
            },
            {
                "index": NotificationIndex.NDB,
                "alertTimeId": 3,
                "alertDistanceId": 13,
                "id": "NDB",
                "timeToPause": "00:00:00",
                "nmToPause": 0,
                "alertTimeSet": false,
                "alertDistanceSet": false,
                "alertTimeSchedule": false,
                "alertDistanceSchedule": false,
                "alertTimeTriggered": false,
                "alertDistanceTriggered": false
            },
            {
                "index": NotificationIndex.FIX,
                "alertTimeId": 4,
                "alertDistanceId": 14,
                "id": "Fix",
                "timeToPause": "00:00:00",
                "nmToPause": 0,
                "alertTimeSet": false,
                "alertDistanceSet": false,
                "alertTimeSchedule": false,
                "alertDistanceSchedule": false,
                "alertTimeTriggered": false,
                "alertDistanceTriggered": false
            },
            {
                "index": NotificationIndex.DME,
                "alertTimeId": 5,
                "alertDistanceId": 15,
                "id": "DME",
                "timeToPause": "00:00:00",
                "nmToPause": 0,
                "alertTimeSet": false,
                "alertDistanceSet": false,
                "alertTimeSchedule": false,
                "alertDistanceSchedule": false,
                "alertTimeTriggered": false,
                "alertDistanceTriggered": false
            }
        ];
        this.storage.get('notifications').then(function (vlr) {
            if (vlr) {
                _this.utils.trace("Load notifications data from LocalStorage:" + vlr);
                _this.notifications = JSON.parse(vlr);
            }
            else {
                _this.saveNotifications();
            }
        });
    }
    NotificationService.prototype.getNotifications = function () {
        return this.notifications;
    };
    NotificationService.prototype.saveNotifications = function () {
        this.storage.set('notifications', JSON.stringify(this.notifications));
    };
    NotificationService.prototype.createRandomAlertId = function () {
        return Math.round(Math.random() * 10000000);
    };
    NotificationService.prototype.checkAlertNotification = function (jsonAirplane) {
        var currentDistance;
        var estimatedTime;
        if (jsonAirplane.pauseforme.navaid.config.selected.airport == 1) {
            currentDistance = jsonAirplane.pauseforme.navaid.config.distance.airport;
            this.checkDistanceAlertNotification(NotificationIndex.AIRPORT, currentDistance, jsonAirplane);
            estimatedTime = this.mapService.etaPauseByNavaIdAirport;
            this.checkTimeAlertNotification(estimatedTime, NotificationIndex.AIRPORT, jsonAirplane, currentDistance);
        }
        if (jsonAirplane.pauseforme.navaid.config.selected.vor == 1) {
            currentDistance = jsonAirplane.pauseforme.navaid.config.distance.vor;
            this.checkDistanceAlertNotification(NotificationIndex.VOR, currentDistance, jsonAirplane);
            estimatedTime = this.mapService.etaPauseByNavaIdVor;
            this.checkTimeAlertNotification(estimatedTime, NotificationIndex.VOR, jsonAirplane, currentDistance);
        }
        if (jsonAirplane.pauseforme.navaid.config.selected.ndb == 1) {
            currentDistance = jsonAirplane.pauseforme.navaid.config.distance.ndb;
            this.checkDistanceAlertNotification(NotificationIndex.NDB, currentDistance, jsonAirplane);
            estimatedTime = this.mapService.etaPauseByNavaIdNdb;
            this.checkTimeAlertNotification(estimatedTime, NotificationIndex.NDB, jsonAirplane, currentDistance);
        }
        if (jsonAirplane.pauseforme.navaid.config.selected.fix == 1) {
            currentDistance = jsonAirplane.pauseforme.navaid.config.distance.fix;
            this.checkDistanceAlertNotification(NotificationIndex.FIX, currentDistance, jsonAirplane);
            estimatedTime = this.mapService.etaPauseByNavaIdFix;
            this.checkTimeAlertNotification(estimatedTime, NotificationIndex.FIX, jsonAirplane, currentDistance);
        }
        if (jsonAirplane.pauseforme.navaid.config.selected.dme == 1) {
            currentDistance = jsonAirplane.pauseforme.navaid.config.distance.dme;
            this.checkDistanceAlertNotification(NotificationIndex.DME, currentDistance, jsonAirplane);
            estimatedTime = this.mapService.etaPauseByNavaIdDme;
            this.checkTimeAlertNotification(estimatedTime, NotificationIndex.DME, jsonAirplane, currentDistance);
        }
    };
    NotificationService.prototype.checkTimeAlertNotification = function (estimatedTime, index, jsonAirplane, currentDistance) {
        // Is Time Alert set and The Time Alert Notification was not yet scheduled?
        if (this.notifications.notification[index].timeToPause != "00:00:00" &&
            !this.notifications.notification[index].alertTimeSet) {
            var notificationTime = this.notifications.notification[index].timeToPause;
            var secondsToTrigger = this.calculateAlertTime(estimatedTime, notificationTime);
            if (secondsToTrigger < 0) {
                secondsToTrigger = 0;
            }
            // If 5 minutes to the Alarm, we'll schedule it to trigger latter
            if (secondsToTrigger <= 300) {
                console.log("Set Time Alarm to trigger in " + secondsToTrigger + " seconds");
                var alertMessage = new AlertMessage();
                alertMessage.id = index + 1; //this.createRandomAlertId();
                alertMessage.typeAlert = AlertType.TIME;
                alertMessage.index = index;
                alertMessage.timeToPause = notificationTime;
                alertMessage.estimatedPause = estimatedTime;
                alertMessage.distance = currentDistance;
                this.fillSpecificAttributesMessage(index, alertMessage, jsonAirplane);
                if (this.createAlert(alertMessage, this.createTimeMessageAlert(alertMessage), secondsToTrigger)) {
                    this.notifications.notification[index].alertTimeSet = true;
                    this.saveNotifications();
                }
            }
        }
    };
    NotificationService.prototype.checkDistanceAlertNotification = function (index, currentDistance, jsonAirplane) {
        // Is Distance Alert set and The Distance Alert Notification was not yet scheduled?
        if (this.notifications.notification[index].nmToPause > 0 &&
            !this.notifications.notification[index].alertDistanceSet) {
            var notificationDistance = this.notifications.notification[index].nmToPause;
            // The current distance is less or equal the requested notification distance?
            if (currentDistance <= notificationDistance) {
                var alertMessage = new AlertMessage();
                alertMessage.id = index + 11; //this.createRandomAlertId();
                alertMessage.typeAlert = AlertType.DISTANCE;
                alertMessage.index = index;
                alertMessage.nmToPause = notificationDistance;
                alertMessage.distance = currentDistance;
                this.fillSpecificAttributesMessage(index, alertMessage, jsonAirplane);
                if (this.createAlert(alertMessage, this.createDistanceMessageAlert(alertMessage), 1)) {
                    this.notifications.notification[index].alertDistanceSet = true;
                    this.saveNotifications();
                }
            }
        }
    };
    NotificationService.prototype.fillSpecificAttributesMessage = function (index, alertMessage, jsonAirplane) {
        if (NotificationIndex.AIRPORT == index) {
            alertMessage.navaId = jsonAirplane.pauseforme.navaid.config.id.airport;
            alertMessage.userDistance = jsonAirplane.pauseforme.navaid.userAirportDistance;
        }
        else if (NotificationIndex.VOR == index) {
            alertMessage.navaId = jsonAirplane.pauseforme.navaid.config.id.vor;
            alertMessage.userDistance = jsonAirplane.pauseforme.navaid.userVORDistance;
        }
        else if (NotificationIndex.NDB == index) {
            alertMessage.navaId = jsonAirplane.pauseforme.navaid.config.id.ndb;
            alertMessage.userDistance = jsonAirplane.pauseforme.navaid.userNDBDistance;
        }
        else if (NotificationIndex.FIX == index) {
            alertMessage.navaId = jsonAirplane.pauseforme.navaid.config.id.fix;
            alertMessage.userDistance = jsonAirplane.pauseforme.navaid.userFixDistance;
        }
        else if (NotificationIndex.DME == index) {
            alertMessage.navaId = jsonAirplane.pauseforme.navaid.config.id.dme;
            alertMessage.userDistance = jsonAirplane.pauseforme.navaid.userDMEDistance;
        }
    };
    NotificationService.prototype.createAlert = function (alertMessage, msg, triggerSeconds) {
        console.log("Creating alert for " + alertMessage.id + " -> " + msg);
        this.localNotifications.schedule({
            id: alertMessage.id,
            title: 'MapPauseForMe - Close to Pause!',
            //icon: 'http://climberindonesia.com/assets/icon/ionicons-2.0.1/png/512/android-chat.png',
            text: msg,
            data: { mydata: alertMessage },
            trigger: { in: triggerSeconds, unit: _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_6__["ELocalNotificationTriggerUnit"].SECOND },
            foreground: true // Show the notification while app is open
        });
        return true;
    };
    NotificationService.prototype.createDistanceMessageAlert = function (alertMessage) {
        return 'We are close to the distance of '
            + alertMessage.nmToPause + ' nm to '
            + alertMessage.navaId + " ("
            + alertMessage.distance + "nm <= "
            + alertMessage.userDistance + "nm)";
    };
    NotificationService.prototype.createTimeMessageAlert = function (alertMessage) {
        var units = "xx";
        var min = parseInt(alertMessage.timeToPause.split(":")[1]);
        var sec = parseInt(alertMessage.timeToPause.split(":")[2]);
        if (min == 0) {
            units = "sec";
        }
        else if (min == 1) {
            units = "min";
        }
        else {
            units = "min";
        }
        return 'We are close to the estimated time of '
            + alertMessage.timeToPause.substr(3) + ' ' + units + ' to pause X-Plane ('
            + alertMessage.navaId + " "
            + alertMessage.distance + "nm <= "
            + alertMessage.userDistance + "nm)";
    };
    NotificationService.prototype.calculateAlertTime = function (estimatedTime, requestedPauseTime) {
        var f = '01/01/2019 ';
        var milisecs = Date.parse(f + estimatedTime) - Date.parse(f + requestedPauseTime);
        return (milisecs / 1000);
    };
    NotificationService.prototype.compareAlerts = function (t1, t2) {
        var f = '01/01/2019 ';
        if (Date.parse(f + t1) > Date.parse(f + t2))
            return 1;
        if (Date.parse(f + t1) < Date.parse(f + t2))
            return -1;
        return 0;
    };
    NotificationService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_storage__WEBPACK_IMPORTED_MODULE_3__["Storage"],
            _utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilsService"],
            _map_service__WEBPACK_IMPORTED_MODULE_1__["MapService"],
            _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_6__["LocalNotifications"]])
    ], NotificationService);
    return NotificationService;
}());



/***/ }),

/***/ "./src/app/services/notification.ts":
/*!******************************************!*\
  !*** ./src/app/services/notification.ts ***!
  \******************************************/
/*! exports provided: notifications */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "notifications", function() { return notifications; });
var notifications = /** @class */ (function () {
    function notifications() {
    }
    return notifications;
}());

// Alarm Set: 
// Means that was already register at device notification system 
// to be launched any seconds ahead
// Alarm Schedule: 
// Means that was programmed at the Notification Page for the user to be created (set)
// at the right moment (close NM to the Navaid or 00:00:00 min before arrived to it)
// Alarm Triggered:
// Means that the notification set was already triggered by the device notification system
// But the still not "CLICK" or "CLOSE" the notification


/***/ }),

/***/ "./src/app/services/xp-websocket.service.ts":
/*!**************************************************!*\
  !*** ./src/app/services/xp-websocket.service.ts ***!
  \**************************************************/
/*! exports provided: XpWebSocketService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "XpWebSocketService", function() { return XpWebSocketService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _utils_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./utils.service */ "./src/app/services/utils.service.ts");




var XpWebSocketService = /** @class */ (function () {
    function XpWebSocketService(utils) {
        this.utils = utils;
    }
    XpWebSocketService.prototype.connect = function (url) {
        this.subject = this.create(url);
        return this.subject;
    };
    XpWebSocketService.prototype.create = function (url) {
        var _this = this;
        try {
            this.ws = new WebSocket(url);
        }
        catch (error) {
            console.log(error);
        }
        var observable = rxjs__WEBPACK_IMPORTED_MODULE_2__["Observable"].create(function (obs) {
            _this.ws.onmessage = obs.next.bind(obs);
            _this.ws.onerror = obs.error.bind(obs);
            _this.ws.onclose = obs.complete.bind(obs);
            return _this.ws.close.bind(_this.ws);
        });
        var observer = {
            next: function (data) {
                if (_this.ws.readyState === WebSocket.OPEN) {
                    _this.ws.send(JSON.stringify(data));
                }
                else {
                    _this.utils.info("WS readyState ==" + _this.ws.readyState);
                }
            },
            error: function (data) {
                _this.utils.error("ERROR..:" + data);
                return _this.ws.error;
            },
            complete: function (data) {
                _this.utils.info("CLOSED..:" + data);
            }
        };
        return rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"].create(observer, observable);
    };
    XpWebSocketService.prototype.setLastMessageReceive = function (msg) {
        this.lastMessageReceived = msg;
    };
    XpWebSocketService.prototype.getLastMessageReceive = function () {
        return this.lastMessageReceived;
    };
    XpWebSocketService.prototype.observable = function () {
        return this.subject;
    };
    XpWebSocketService.prototype.messageStream = function () {
        var _this = this;
        return new rxjs__WEBPACK_IMPORTED_MODULE_2__["Observable"](function (observer) {
            setInterval(function () {
                if (_this.getLastMessageReceive()) {
                    observer.next(_this.getLastMessageReceive());
                }
                else {
                    observer.error(" Not available! ");
                }
            }, 1000);
        });
    };
    XpWebSocketService.prototype.getWebSocket = function () {
        return this.ws;
    };
    XpWebSocketService.prototype.disconnect = function () {
        if (this.ws) {
            this.utils.info("Closing connection...");
            this.ws.close();
            this.ws = null;
        }
    };
    XpWebSocketService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_utils_service__WEBPACK_IMPORTED_MODULE_3__["UtilsService"]])
    ], XpWebSocketService);
    return XpWebSocketService;
}());



/***/ })

}]);
//# sourceMappingURL=default~pages-map-map-module~pages-notification-notification-module.js.map