(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/es5/build lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ namespace object ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./0jv2gqw7.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0jv2gqw7.entry.js",
		"common",
		10
	],
	"./0jv2gqw7.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0jv2gqw7.sc.entry.js",
		"common",
		11
	],
	"./1hlqf399.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1hlqf399.entry.js",
		"common",
		54
	],
	"./1hlqf399.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1hlqf399.sc.entry.js",
		"common",
		55
	],
	"./1smtjtrp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1smtjtrp.entry.js",
		"common",
		56
	],
	"./1smtjtrp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1smtjtrp.sc.entry.js",
		"common",
		57
	],
	"./2fikn3fc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2fikn3fc.entry.js",
		0,
		"common",
		128
	],
	"./2fikn3fc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2fikn3fc.sc.entry.js",
		0,
		"common",
		129
	],
	"./3ul05w05.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3ul05w05.entry.js",
		"common",
		58
	],
	"./3ul05w05.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3ul05w05.sc.entry.js",
		"common",
		59
	],
	"./4zh8hiut.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4zh8hiut.entry.js",
		0,
		"common",
		130
	],
	"./4zh8hiut.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4zh8hiut.sc.entry.js",
		0,
		"common",
		131
	],
	"./5esrbynz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5esrbynz.entry.js",
		"common",
		102
	],
	"./5esrbynz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5esrbynz.sc.entry.js",
		"common",
		103
	],
	"./5ptcnpes.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5ptcnpes.entry.js",
		"common",
		12
	],
	"./5ptcnpes.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5ptcnpes.sc.entry.js",
		"common",
		13
	],
	"./5pwuvxkr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5pwuvxkr.entry.js",
		"common",
		60
	],
	"./5pwuvxkr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5pwuvxkr.sc.entry.js",
		"common",
		61
	],
	"./5vxaf0jn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5vxaf0jn.entry.js",
		"common",
		62
	],
	"./5vxaf0jn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5vxaf0jn.sc.entry.js",
		"common",
		63
	],
	"./6dsdnxyn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6dsdnxyn.entry.js",
		"common",
		64
	],
	"./6dsdnxyn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6dsdnxyn.sc.entry.js",
		"common",
		65
	],
	"./6kgso7pq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6kgso7pq.entry.js",
		"common",
		14
	],
	"./6kgso7pq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6kgso7pq.sc.entry.js",
		"common",
		15
	],
	"./6pwd4qif.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6pwd4qif.entry.js",
		"common",
		104
	],
	"./6pwd4qif.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6pwd4qif.sc.entry.js",
		"common",
		105
	],
	"./7xggbwe8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7xggbwe8.entry.js",
		"common",
		66
	],
	"./7xggbwe8.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7xggbwe8.sc.entry.js",
		"common",
		67
	],
	"./8odyguue.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8odyguue.entry.js",
		"common",
		68
	],
	"./8odyguue.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8odyguue.sc.entry.js",
		"common",
		69
	],
	"./aavh7iu1.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/aavh7iu1.entry.js",
		0,
		"common",
		132
	],
	"./aavh7iu1.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/aavh7iu1.sc.entry.js",
		0,
		"common",
		133
	],
	"./admmxern.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/admmxern.entry.js",
		"common",
		70
	],
	"./admmxern.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/admmxern.sc.entry.js",
		"common",
		71
	],
	"./apfh3flu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/apfh3flu.entry.js",
		"common",
		16
	],
	"./apfh3flu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/apfh3flu.sc.entry.js",
		"common",
		17
	],
	"./bngjpe45.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bngjpe45.entry.js",
		"common",
		18
	],
	"./bngjpe45.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bngjpe45.sc.entry.js",
		"common",
		19
	],
	"./cwd9g9my.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cwd9g9my.entry.js",
		"common",
		100
	],
	"./cwd9g9my.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cwd9g9my.sc.entry.js",
		"common",
		101
	],
	"./dsb5jv5r.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dsb5jv5r.entry.js",
		"common",
		20
	],
	"./dsb5jv5r.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dsb5jv5r.sc.entry.js",
		"common",
		21
	],
	"./ejapjnva.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ejapjnva.entry.js",
		"common",
		72
	],
	"./ejapjnva.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ejapjnva.sc.entry.js",
		"common",
		73
	],
	"./fuq8m3zo.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fuq8m3zo.entry.js",
		"common",
		22
	],
	"./fuq8m3zo.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fuq8m3zo.sc.entry.js",
		"common",
		23
	],
	"./fwzyk2t9.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fwzyk2t9.entry.js",
		"common",
		24
	],
	"./fwzyk2t9.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fwzyk2t9.sc.entry.js",
		"common",
		25
	],
	"./g7y3qohv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/g7y3qohv.entry.js",
		0,
		"common",
		136
	],
	"./g7y3qohv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/g7y3qohv.sc.entry.js",
		0,
		"common",
		137
	],
	"./gbcxupo7.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gbcxupo7.entry.js",
		"common",
		74
	],
	"./gbcxupo7.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gbcxupo7.sc.entry.js",
		"common",
		75
	],
	"./gtqqbhae.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gtqqbhae.entry.js",
		"common",
		26
	],
	"./gtqqbhae.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gtqqbhae.sc.entry.js",
		"common",
		27
	],
	"./hdjqcfvf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hdjqcfvf.entry.js",
		"common",
		28
	],
	"./hdjqcfvf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hdjqcfvf.sc.entry.js",
		"common",
		29
	],
	"./helxzsef.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/helxzsef.entry.js",
		138
	],
	"./helxzsef.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/helxzsef.sc.entry.js",
		139
	],
	"./hg9mfbbd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hg9mfbbd.entry.js",
		"common",
		76
	],
	"./hg9mfbbd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hg9mfbbd.sc.entry.js",
		"common",
		77
	],
	"./hqq2qdqe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hqq2qdqe.entry.js",
		0,
		"common",
		140
	],
	"./hqq2qdqe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hqq2qdqe.sc.entry.js",
		0,
		"common",
		141
	],
	"./i5bu78vq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i5bu78vq.entry.js",
		"common",
		78
	],
	"./i5bu78vq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i5bu78vq.sc.entry.js",
		"common",
		79
	],
	"./ibsc94yw.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ibsc94yw.entry.js",
		"common",
		106
	],
	"./ibsc94yw.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ibsc94yw.sc.entry.js",
		"common",
		107
	],
	"./ipk81gk6.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ipk81gk6.entry.js",
		142
	],
	"./ipk81gk6.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ipk81gk6.sc.entry.js",
		143
	],
	"./iqlhkurd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iqlhkurd.entry.js",
		"common",
		80
	],
	"./iqlhkurd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iqlhkurd.sc.entry.js",
		"common",
		81
	],
	"./isuxxasv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/isuxxasv.entry.js",
		"common",
		82
	],
	"./isuxxasv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/isuxxasv.sc.entry.js",
		"common",
		83
	],
	"./j241fzpw.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j241fzpw.entry.js",
		"common",
		30
	],
	"./j241fzpw.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j241fzpw.sc.entry.js",
		"common",
		31
	],
	"./j6a9duez.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j6a9duez.entry.js",
		"common",
		32
	],
	"./j6a9duez.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j6a9duez.sc.entry.js",
		"common",
		33
	],
	"./j9orjvxv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j9orjvxv.entry.js",
		"common",
		112
	],
	"./j9orjvxv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j9orjvxv.sc.entry.js",
		"common",
		113
	],
	"./j9sczdb9.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j9sczdb9.entry.js",
		"common",
		34
	],
	"./j9sczdb9.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j9sczdb9.sc.entry.js",
		"common",
		35
	],
	"./jdmqrxbv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jdmqrxbv.entry.js",
		"common",
		36
	],
	"./jdmqrxbv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jdmqrxbv.sc.entry.js",
		"common",
		37
	],
	"./jpkvsu5y.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jpkvsu5y.entry.js",
		"common",
		114
	],
	"./jpkvsu5y.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jpkvsu5y.sc.entry.js",
		"common",
		115
	],
	"./k4hoilf4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/k4hoilf4.entry.js",
		"common",
		84
	],
	"./k4hoilf4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/k4hoilf4.sc.entry.js",
		"common",
		85
	],
	"./ka5tcqxv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ka5tcqxv.entry.js",
		0,
		"common",
		144
	],
	"./ka5tcqxv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ka5tcqxv.sc.entry.js",
		0,
		"common",
		145
	],
	"./ksgex3rj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ksgex3rj.entry.js",
		"common",
		38
	],
	"./ksgex3rj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ksgex3rj.sc.entry.js",
		"common",
		39
	],
	"./kwsaahen.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kwsaahen.entry.js",
		2,
		"common",
		146
	],
	"./kwsaahen.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kwsaahen.sc.entry.js",
		2,
		"common",
		147
	],
	"./mri9bdlj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mri9bdlj.entry.js",
		148
	],
	"./mri9bdlj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mri9bdlj.sc.entry.js",
		149
	],
	"./okzvvz1s.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/okzvvz1s.entry.js",
		"common",
		40
	],
	"./okzvvz1s.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/okzvvz1s.sc.entry.js",
		"common",
		41
	],
	"./omfdyboy.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/omfdyboy.entry.js",
		"common",
		116
	],
	"./omfdyboy.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/omfdyboy.sc.entry.js",
		"common",
		117
	],
	"./oopkmdhe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oopkmdhe.entry.js",
		0,
		"common",
		108
	],
	"./oopkmdhe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oopkmdhe.sc.entry.js",
		0,
		"common",
		109
	],
	"./paaaniyp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/paaaniyp.entry.js",
		"common",
		118
	],
	"./paaaniyp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/paaaniyp.sc.entry.js",
		"common",
		119
	],
	"./pcvyposn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pcvyposn.entry.js",
		"common",
		42
	],
	"./pcvyposn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pcvyposn.sc.entry.js",
		"common",
		43
	],
	"./qcbg1abo.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qcbg1abo.entry.js",
		"common",
		120
	],
	"./qcbg1abo.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qcbg1abo.sc.entry.js",
		"common",
		121
	],
	"./qjwxr7dv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qjwxr7dv.entry.js",
		"common",
		44
	],
	"./qjwxr7dv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qjwxr7dv.sc.entry.js",
		"common",
		45
	],
	"./qmw4agos.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qmw4agos.entry.js",
		0,
		"common",
		150
	],
	"./qmw4agos.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qmw4agos.sc.entry.js",
		0,
		"common",
		151
	],
	"./qoe6pe8v.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qoe6pe8v.entry.js",
		"common",
		46
	],
	"./qoe6pe8v.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qoe6pe8v.sc.entry.js",
		"common",
		47
	],
	"./qqusykhh.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qqusykhh.entry.js",
		"common",
		86
	],
	"./qqusykhh.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qqusykhh.sc.entry.js",
		"common",
		87
	],
	"./qutdmiwk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qutdmiwk.entry.js",
		0,
		"common",
		152
	],
	"./qutdmiwk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qutdmiwk.sc.entry.js",
		0,
		"common",
		153
	],
	"./rcclotvr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rcclotvr.entry.js",
		2,
		"common",
		154
	],
	"./rcclotvr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rcclotvr.sc.entry.js",
		2,
		"common",
		155
	],
	"./rkecsmgc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rkecsmgc.entry.js",
		"common",
		122
	],
	"./rkecsmgc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rkecsmgc.sc.entry.js",
		"common",
		123
	],
	"./rrpxfm2a.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rrpxfm2a.entry.js",
		156
	],
	"./rrpxfm2a.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rrpxfm2a.sc.entry.js",
		157
	],
	"./rvwuhvz4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rvwuhvz4.entry.js",
		0,
		"common",
		158
	],
	"./rvwuhvz4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rvwuhvz4.sc.entry.js",
		0,
		"common",
		159
	],
	"./tlbladaf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tlbladaf.entry.js",
		"common",
		48
	],
	"./tlbladaf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tlbladaf.sc.entry.js",
		"common",
		49
	],
	"./tsx41s3c.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tsx41s3c.entry.js",
		"common",
		50
	],
	"./tsx41s3c.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tsx41s3c.sc.entry.js",
		"common",
		51
	],
	"./txpe5bol.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/txpe5bol.entry.js",
		"common",
		88
	],
	"./txpe5bol.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/txpe5bol.sc.entry.js",
		"common",
		89
	],
	"./vhwyavqm.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vhwyavqm.entry.js",
		"common",
		52
	],
	"./vhwyavqm.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vhwyavqm.sc.entry.js",
		"common",
		53
	],
	"./vnwnpb93.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vnwnpb93.entry.js",
		"common",
		124
	],
	"./vnwnpb93.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vnwnpb93.sc.entry.js",
		"common",
		125
	],
	"./w6supv7p.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/w6supv7p.entry.js",
		"common",
		90
	],
	"./w6supv7p.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/w6supv7p.sc.entry.js",
		"common",
		91
	],
	"./wjdsdnuu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wjdsdnuu.entry.js",
		"common",
		92
	],
	"./wjdsdnuu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wjdsdnuu.sc.entry.js",
		"common",
		93
	],
	"./wpzpc9xw.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wpzpc9xw.entry.js",
		0,
		"common",
		110
	],
	"./wpzpc9xw.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wpzpc9xw.sc.entry.js",
		0,
		"common",
		111
	],
	"./xrssylnk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xrssylnk.entry.js",
		0,
		"common",
		160
	],
	"./xrssylnk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xrssylnk.sc.entry.js",
		0,
		"common",
		161
	],
	"./ylecf5ox.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ylecf5ox.entry.js",
		"common",
		94
	],
	"./ylecf5ox.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ylecf5ox.sc.entry.js",
		"common",
		95
	],
	"./yu8fzdyg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/yu8fzdyg.entry.js",
		0,
		"common",
		162
	],
	"./yu8fzdyg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/yu8fzdyg.sc.entry.js",
		0,
		"common",
		163
	],
	"./yxoiyuhs.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/yxoiyuhs.entry.js",
		"common",
		96
	],
	"./yxoiyuhs.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/yxoiyuhs.sc.entry.js",
		"common",
		97
	],
	"./zc63qizl.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zc63qizl.entry.js",
		"common",
		98
	],
	"./zc63qizl.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zc63qizl.sc.entry.js",
		"common",
		99
	],
	"./ziv0mko0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ziv0mko0.entry.js",
		"common",
		126
	],
	"./ziv0mko0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ziv0mko0.sc.entry.js",
		"common",
		127
	],
	"./zxjlzr69.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zxjlzr69.entry.js",
		0,
		"common",
		164
	],
	"./zxjlzr69.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zxjlzr69.sc.entry.js",
		0,
		"common",
		165
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./pages/airplane/airplane.module": [
		"./src/app/pages/airplane/airplane.module.ts",
		"default~pages-airplane-airplane-module~pages-map-map-module~pages-setting-setting-module",
		"common",
		"pages-airplane-airplane-module"
	],
	"./pages/map/map.module": [
		"./src/app/pages/map/map.module.ts",
		"default~pages-airplane-airplane-module~pages-map-map-module~pages-setting-setting-module",
		"default~pages-map-map-module~pages-notification-notification-module",
		"common",
		"pages-map-map-module"
	],
	"./pages/notification/notification.module": [
		"./src/app/pages/notification/notification.module.ts",
		"default~pages-map-map-module~pages-notification-notification-module",
		"common",
		"pages-notification-notification-module"
	],
	"./pages/pause-for-me/pause-for-me.module": [
		"./src/app/pages/pause-for-me/pause-for-me.module.ts",
		"common",
		"pages-pause-for-me-pause-for-me-module"
	],
	"./pages/setting/setting.module": [
		"./src/app/pages/setting/setting.module.ts",
		"default~pages-airplane-airplane-module~pages-map-map-module~pages-setting-setting-module",
		"common",
		"pages-setting-setting-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var routes = [
    { path: '', redirectTo: 'map', pathMatch: 'full' },
    { path: 'map', loadChildren: './pages/map/map.module#MapPageModule' },
    { path: 'setting', loadChildren: './pages/setting/setting.module#SettingPageModule' },
    { path: 'airplane', loadChildren: './pages/airplane/airplane.module#AirplanePageModule' },
    { path: 'pause-for-me', loadChildren: './pages/pause-for-me/pause-for-me.module#PauseForMePageModule' },
    { path: 'notification', loadChildren: './pages/notification/notification.module#NotificationPageModule' }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\n  <ion-split-pane when=\"false\">\n    <ion-menu>\n      <ion-header>\n        <ion-toolbar>\n          <ion-title>Menu</ion-title>\n        </ion-toolbar>\n      </ion-header>\n      <ion-content>\n        <ion-list>\n          <ion-menu-toggle *ngFor=\"let p of appPages\">\n            <ion-item routerDirection=\"forward\" [routerLink]=\"[p.url]\">\n              <ion-icon slot=\"start\" [name]=\"p.icon\" mode=\"ios\"></ion-icon>\n              <ion-label>\n                {{p.title}}\n              </ion-label>\n            </ion-item>\n          </ion-menu-toggle>\n        </ion-list>\n      </ion-content>\n    </ion-menu>\n    <ion-router-outlet main></ion-router-outlet>\n  </ion-split-pane>\n</ion-app>\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _ionic_native_insomnia_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/insomnia/ngx */ "./node_modules/@ionic-native/insomnia/ngx/index.js");






var AppComponent = /** @class */ (function () {
    function AppComponent(platform, splashScreen, statusBar, insomnia) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.insomnia = insomnia;
        this.appPages = [
            {
                title: 'Settings',
                url: '/setting',
                icon: 'cog'
            },
            {
                title: 'PauseForMe',
                url: '/pause-for-me',
                icon: 'pause'
            },
            {
                title: 'Notifications',
                url: '/notification',
                icon: 'notifications'
            }
        ];
        this.initializeApp();
    }
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
            _this.insomnia.keepAwake()
                .then(function () { return console.log('Insomnia success activated'); }, function () { return console.log('ERROR: Insomnia attempting activate'); });
        });
    };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html")
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"],
            _ionic_native_insomnia_ngx__WEBPACK_IMPORTED_MODULE_5__["Insomnia"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/geolocation/ngx */ "./node_modules/@ionic-native/geolocation/ngx/index.js");
/* harmony import */ var _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/local-notifications/ngx */ "./node_modules/@ionic-native/local-notifications/ngx/index.js");
/* harmony import */ var _ionic_native_background_mode_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic-native/background-mode/ngx */ "./node_modules/@ionic-native/background-mode/ngx/index.js");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_native_insomnia_ngx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic-native/insomnia/ngx */ "./node_modules/@ionic-native/insomnia/ngx/index.js");
/* harmony import */ var _angular_service_worker__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/service-worker */ "./node_modules/@angular/service-worker/fesm5/service-worker.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../environments/environment */ "./src/environments/environment.ts");


















var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]],
            entryComponents: [],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_9__["BrowserAnimationsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(),
                _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"],
                _ionic_storage__WEBPACK_IMPORTED_MODULE_10__["IonicStorageModule"].forRoot(),
                _angular_service_worker__WEBPACK_IMPORTED_MODULE_16__["ServiceWorkerModule"].register('ngsw-worker.js', { enabled: _environments_environment__WEBPACK_IMPORTED_MODULE_17__["environment"].production })
            ],
            providers: [
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"],
                _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_11__["Geolocation"],
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] },
                _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_12__["LocalNotifications"],
                _ionic_native_background_mode_ngx__WEBPACK_IMPORTED_MODULE_13__["BackgroundMode"],
                _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_14__["ScreenOrientation"],
                _ionic_native_insomnia_ngx__WEBPACK_IMPORTED_MODULE_15__["Insomnia"]
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\Developer\code\ionic\xp-pauseforme-v1\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map