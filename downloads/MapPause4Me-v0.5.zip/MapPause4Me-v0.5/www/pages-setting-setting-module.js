(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-setting-setting-module"],{

/***/ "./src/app/pages/setting/setting.module.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/setting/setting.module.ts ***!
  \*************************************************/
/*! exports provided: SettingPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingPageModule", function() { return SettingPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _setting_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./setting.page */ "./src/app/pages/setting/setting.page.ts");







var routes = [
    {
        path: '',
        component: _setting_page__WEBPACK_IMPORTED_MODULE_6__["SettingPage"]
    }
];
var SettingPageModule = /** @class */ (function () {
    function SettingPageModule() {
    }
    SettingPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_setting_page__WEBPACK_IMPORTED_MODULE_6__["SettingPage"]]
        })
    ], SettingPageModule);
    return SettingPageModule;
}());



/***/ }),

/***/ "./src/app/pages/setting/setting.page.html":
/*!*************************************************!*\
  !*** ./src/app/pages/setting/setting.page.html ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!--\n  Generated template for the SettingsPage page.\n\n  See http://ionicframework.com/docs/components/#navigation for more info on\n  Ionic pages and navigation.\n-->\n<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>\n      Settings\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content class=\"background\">\n  <div class=\"page-config\">\n    <ion-list>\n        <ion-item-group>\n          <ion-list-header class=\"listHeader\">\n            <ion-label>\n                <ion-thumbnail class=\"ion-thumbnailSize paddingLeft\"><img src=\"assets/imgs/xplane-logo-35.png\" class=\"imgThumbnailSize\" style=\"width:35px;height:35px;margin-right: 10px;\" ></ion-thumbnail>\n            </ion-label>\n            <ion-label>X-Plane Communication</ion-label>\n          </ion-list-header>\n          <ion-item lines=\"full\">\n            <ion-icon name=\"link\"  class=\"iconItem paddingLeft\" mode=\"ios\"></ion-icon>\n            <ion-label>Address:</ion-label>\n            <ion-input type=\"text\" placeholder=\"127.0.0.1\" [(ngModel)]=\"xplaneAddress\" id=\"inputXplaneAddress\" color=\"primary\" (ionBlur)=\"onFocusLostEvent($event)\"></ion-input>\n          </ion-item>\n          <ion-item lines=\"full\">\n            <ion-icon name=\"link\" class=\"iconItem paddingLeft\" mode=\"ios\"></ion-icon>\n            <ion-label>Port:</ion-label>\n            <ion-input type=\"text\" placeholder=\"9002\" [(ngModel)]=\"xplanePort\" id=\"inputXplanePort\" (ionBlur)=\"onFocusLostEvent($event)\"></ion-input>\n          </ion-item>\n\n          <ion-item-divider lines=\"full\" class=\"config\"></ion-item-divider>\n\n          <ion-list-header class=\"listHeader padding\">\n            <ion-label>\n              <ion-icon name=\"person\" color=\"primary\" class=\"iconItemHeader paddingLeft\" mode=\"ios\"></ion-icon>\n            </ion-label>\n            <ion-label>Me</ion-label>\n          </ion-list-header>\n          <ion-item lines=\"full\">\n            <ion-icon name=\"phone-portrait\" class=\"iconItem paddingLeft\" mode=\"ios\"></ion-icon>\n            <ion-label>Name:</ion-label>\n            <ion-input type=\"text\" placeholder=\"UALTER iPhone\" [(ngModel)]=\"deviceName\" id=\"inputDeviceName\" (ionBlur)=\"onFocusLostEvent($event)\"></ion-input>\n          </ion-item>\n\n          <ion-item-divider lines=\"full\" class=\"config\"></ion-item-divider>\n\n          <ion-list-header class=\"listHeader padding\">\n              <ion-label>\n                  <ion-icon name=\"airplane\" color=\"primary\" class=\"iconItemHeader paddingLeft\" mode=\"ios\"></ion-icon>  \n              </ion-label>\n              <ion-label>Airplane</ion-label>\n          </ion-list-header>\n          <ion-item lines=\"full\" button (click)=\"openAirplanesPage()\" style=\"justify-content: end\">\n              <ion-label style=\"flex:none !important;\" class=\"paddingLeft\">\n                <ion-thumbnail class=\"ion-thumbnailSize\">\n                  <ion-img [src]=\"airplane.icon\" style=\"width: 60px; height: 60px; margin-right: 10px;\"></ion-img>\n                </ion-thumbnail>\n              </ion-label>\n              <ion-label>{{airplane.name}}</ion-label>\n              <ion-label>&nbsp;</ion-label>\n              <ion-label>&nbsp;</ion-label>\n          </ion-item>\n\n        </ion-item-group>\n    </ion-list>\n\n  </div>\n</ion-content>\n\n"

/***/ }),

/***/ "./src/app/pages/setting/setting.page.scss":
/*!*************************************************!*\
  !*** ./src/app/pages/setting/setting.page.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".iconItem {\n  font-size: 20px;\n  margin-right: 5px; }\n\n.iconItemHeader {\n  font-size: 35px;\n  margin-right: 10px; }\n\n@media (min-width: 650px) {\n  .page-config {\n    margin-left: auto;\n    margin-right: auto;\n    width: var(--pauseforme-width-max);\n    box-shadow: 3px 3px 6px 4px rgba(50, 50, 50, 0.6); }\n  ion-content.background {\n    --background: var(--pauseform-background); }\n  .paddingLeft {\n    padding-left: 30px; } }\n\n@media (min-width: 480px) and (max-width: 649px) {\n  .paddingLeft {\n    padding-left: 10px; } }\n\n.buttonSaveRow {\n  padding: 30px 0px 30px 0px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc2V0dGluZy9EOlxcRGV2ZWxvcGVyXFxjb2RlXFxpb25pY1xceHAtcGF1c2Vmb3JtZS12MS9zcmNcXGFwcFxccGFnZXNcXHNldHRpbmdcXHNldHRpbmcucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksZUFBZTtFQUNmLGlCQUFpQixFQUFBOztBQUdyQjtFQUNJLGVBQWU7RUFDZixrQkFBa0IsRUFBQTs7QUFHdEI7RUFDSTtJQUNJLGlCQUFnQjtJQUNoQixrQkFBaUI7SUFDakIsa0NBQWtDO0lBR2xDLGlEQUEwRCxFQUFBO0VBRTlEO0lBQ0kseUNBQWEsRUFBQTtFQUVqQjtJQUNJLGtCQUFrQixFQUFBLEVBQ3JCOztBQUdMO0VBQ0k7SUFDSSxrQkFBa0IsRUFBQSxFQUNyQjs7QUFHTDtFQUNJLDBCQUF5QixFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvc2V0dGluZy9zZXR0aW5nLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4uaWNvbkl0ZW0ge1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA1cHg7XHJcbn1cclxuXHJcbi5pY29uSXRlbUhlYWRlciB7XHJcbiAgICBmb250LXNpemU6IDM1cHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbn1cclxuXHJcbkBtZWRpYSAobWluLXdpZHRoOjY1MHB4KSB7IC8vIHRoaXMgcnVsZSB3aWxsIG9ubHkgdHJpZ2dlciBpZiBzY3JlZW4gd2lkdGggaXMgYWJvdmUgWHB4LFxyXG4gICAgLnBhZ2UtY29uZmlnIHtcclxuICAgICAgICBtYXJnaW4tbGVmdDphdXRvO1xyXG4gICAgICAgIG1hcmdpbi1yaWdodDphdXRvO1xyXG4gICAgICAgIHdpZHRoOiB2YXIoLS1wYXVzZWZvcm1lLXdpZHRoLW1heCk7XHJcbiAgICAgICAgLW1vei1ib3gtc2hhZG93OiAgICAzcHggM3B4IDZweCA0cHggcmdiYSg1MCwgNTAsIDUwLCAwLjYwKTtcclxuICAgICAgICAtd2Via2l0LWJveC1zaGFkb3c6IDNweCAzcHggNnB4IDRweCByZ2JhKDUwLCA1MCwgNTAsIDAuNjApO1xyXG4gICAgICAgIGJveC1zaGFkb3c6ICAgICAgICAgM3B4IDNweCA2cHggNHB4IHJnYmEoNTAsIDUwLCA1MCwgMC42MCk7XHJcbiAgICB9XHJcbiAgICBpb24tY29udGVudC5iYWNrZ3JvdW5kIHtcclxuICAgICAgICAtLWJhY2tncm91bmQ6IHZhcigtLXBhdXNlZm9ybS1iYWNrZ3JvdW5kKTtcclxuICAgIH1cclxuICAgIC5wYWRkaW5nTGVmdCB7XHJcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAzMHB4O1xyXG4gICAgfVxyXG59XHJcblxyXG5AbWVkaWEgKG1pbi13aWR0aDo0ODBweCkgYW5kIChtYXgtd2lkdGg6NjQ5cHgpIHtcclxuICAgIC5wYWRkaW5nTGVmdCB7XHJcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gICAgfVxyXG59XHJcblxyXG4uYnV0dG9uU2F2ZVJvdyB7XHJcbiAgICBwYWRkaW5nOjMwcHggMHB4IDMwcHggMHB4O1xyXG59XHJcblxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/pages/setting/setting.page.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/setting/setting.page.ts ***!
  \***********************************************/
/*! exports provided: SettingPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingPage", function() { return SettingPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/data.service */ "./src/app/services/data.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _services_airplane_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/airplane.service */ "./src/app/services/airplane.service.ts");






var SettingPage = /** @class */ (function () {
    function SettingPage(navCtrl, dataService, airplaneService, utils) {
        var _this = this;
        this.navCtrl = navCtrl;
        this.dataService = dataService;
        this.airplaneService = airplaneService;
        this.utils = utils;
        this.xplaneAddress = "localhost";
        this.xplanePort = "9002";
        this.deviceName = "UALTER Desktop";
        this.dataService.currentSettings.subscribe(function (settings) {
            _this.xplaneAddress = settings.xplaneAddress;
            _this.xplanePort = settings.xplanePort;
            _this.deviceName = settings.name;
            _this.airplane = _this.airplaneService.getAirplane(settings.airplaneId);
            if (_this.airplane) {
                _this.airplaneId = _this.airplane.id;
            }
        });
        if (!this.airplane) {
            this.airplane = this.airplaneService.getAirplane("a320");
        }
    }
    SettingPage.prototype.ngOnInit = function () {
    };
    SettingPage.prototype.ionViewDidLoad = function () {
    };
    SettingPage.prototype.ionViewWillEnter = function () {
        this.airplane = this.airplaneService.getAirplane(this.dataService.settings.airplaneId);
    };
    SettingPage.prototype.saveSettings = function () {
        var notify = false;
        if (this.xplaneAddress != this.dataService.settings.xplaneAddress) {
            this.dataService.changeSettingsXplaneAddress(this.xplaneAddress);
            notify = true;
        }
        if (this.xplanePort != this.dataService.settings.xplanePort) {
            this.dataService.changeSettingsXplanePort(this.xplanePort);
            notify = true;
        }
        if (this.deviceName != this.dataService.settings.name) {
            this.dataService.changeSettingsName(this.deviceName);
            notify = true;
        }
        if (this.airplaneId != this.dataService.settings.airplaneId) {
            notify = true;
        }
        if (notify) {
            this.dataService.saveSettings();
            this.dataService.notifyChangeSettingsToSubscribers();
        }
    };
    SettingPage.prototype.openAirplanesPage = function () {
        this.navCtrl.navigateForward('/airplane');
    };
    SettingPage.prototype.onFocusLostEvent = function (event) {
        var input = event['target'];
        if (input.id == "inputXplaneAddress") {
            if (this.xplaneAddress != this.dataService.settings.xplaneAddress) {
                this.dataService.changeSettingsXplaneAddress(this.xplaneAddress);
                this.dataService.saveSettings();
                this.dataService.notifyChangeSettingsToSubscribers();
            }
        }
        else if (input.id == "inputXplanePort") {
            if (this.xplanePort != this.dataService.settings.xplanePort) {
                this.dataService.changeSettingsXplanePort(this.xplanePort);
                this.dataService.saveSettings();
                this.dataService.notifyChangeSettingsToSubscribers();
            }
        }
        else if (input.id == "inputDeviceName") {
            if (this.deviceName != this.dataService.settings.name) {
                this.dataService.changeSettingsName(this.deviceName);
                this.dataService.saveSettings();
                this.dataService.notifyChangeSettingsToSubscribers();
            }
        }
    };
    SettingPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-setting',
            template: __webpack_require__(/*! ./setting.page.html */ "./src/app/pages/setting/setting.page.html"),
            styles: [__webpack_require__(/*! ./setting.page.scss */ "./src/app/pages/setting/setting.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"],
            _services_airplane_service__WEBPACK_IMPORTED_MODULE_5__["AirplaneService"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilsService"]])
    ], SettingPage);
    return SettingPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-setting-setting-module.js.map