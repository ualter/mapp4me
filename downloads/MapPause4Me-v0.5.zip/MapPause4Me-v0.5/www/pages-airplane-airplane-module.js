(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-airplane-airplane-module"],{

/***/ "./src/app/pages/airplane/airplane.module.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/airplane/airplane.module.ts ***!
  \***************************************************/
/*! exports provided: AirplanePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AirplanePageModule", function() { return AirplanePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _airplane_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./airplane.page */ "./src/app/pages/airplane/airplane.page.ts");







var routes = [
    {
        path: '',
        component: _airplane_page__WEBPACK_IMPORTED_MODULE_6__["AirplanePage"]
    }
];
var AirplanePageModule = /** @class */ (function () {
    function AirplanePageModule() {
    }
    AirplanePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_airplane_page__WEBPACK_IMPORTED_MODULE_6__["AirplanePage"]]
        })
    ], AirplanePageModule);
    return AirplanePageModule;
}());



/***/ }),

/***/ "./src/app/pages/airplane/airplane.page.html":
/*!***************************************************!*\
  !*** ./src/app/pages/airplane/airplane.page.html ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>\n      Airplanes\n    </ion-title>\n  </ion-toolbar>\n  <div class=\"page-config\">\n  <ion-segment [(ngModel)]=\"airliner\" > \n    <ion-segment-button *ngFor=\"let item of listAirliners()\" value=\"{{item}}\">\n        {{item}}\n    </ion-segment-button>\n  </ion-segment>\n  </div>\n</ion-header>\n\n<ion-content class=\"background\">\n  <div class=\"page-config\">\n    <div [ngSwitch]=\"airliner\">\n      <ng-container *ngFor=\"let item of listAirliners()\">\n          <ion-list  ngDefaultControl *ngSwitchCase=\"item\" (ionChange)=\"onChangeHandler($event)\">\n            <ion-radio-group  [(ngModel)]=\"model\">\n                <ion-item *ngFor=\"let airplane of listAirplanes(item)\">\n                    <ion-grid>\n                      <ion-row class=\"ion-align-items-center ion-justify-content-center\">\n                        <ion-col>\n                            <div style=\"display: flex; justify-content: center; align-items: center;\">\n                              <ion-thumbnail>\n                                  <img src=\"{{airplane.icon}}\" alt=\"{{airplane.icon}}\">\n                              </ion-thumbnail>\n                            </div>  \n                        </ion-col>\n                        <ion-col>\n                            {{airplane.name}}\n                        </ion-col>\n                        <ion-col>\n                            <div style=\"/*display: flex; justify-content: center; align-items: center;*/margin-left: 30px;\">\n                                <ion-radio value=\"{{airplane.id}}\" checked></ion-radio>\n                            </div>\n                        </ion-col>\n                      </ion-row>\n                    </ion-grid>\n                </ion-item>\n            </ion-radio-group>\n          </ion-list>\n      </ng-container>    \n    </div>  \n  </div>  \n  </ion-content>\n"

/***/ }),

/***/ "./src/app/pages/airplane/airplane.page.scss":
/*!***************************************************!*\
  !*** ./src/app/pages/airplane/airplane.page.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@media (min-width: 650px) {\n  .page-config {\n    margin-left: auto;\n    margin-right: auto;\n    width: var(--pauseforme-width-max);\n    box-shadow: 3px 3px 6px 4px rgba(50, 50, 50, 0.6); }\n  .navaidsContainer {\n    padding: 0px 30px 0 30px; }\n  .headerSection {\n    padding-left: 30px;\n    padding-right: 30px; }\n  ion-list.padding {\n    padding: 0px 50px 50px 50px; }\n  ion-content.background {\n    --background: var(--pauseform-background); } }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYWlycGxhbmUvRDpcXERldmVsb3BlclxcY29kZVxcaW9uaWNcXHhwLXBhdXNlZm9ybWUtdjEvc3JjXFxhcHBcXHBhZ2VzXFxhaXJwbGFuZVxcYWlycGxhbmUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0k7SUFDSSxpQkFBZ0I7SUFDaEIsa0JBQWlCO0lBQ2pCLGtDQUFrQztJQUdsQyxpREFBMEQsRUFBQTtFQUU5RDtJQUNJLHdCQUF3QixFQUFBO0VBRTVCO0lBQ0ksa0JBQWtCO0lBQ2xCLG1CQUFtQixFQUFBO0VBRXZCO0lBQ0ksMkJBQTJCLEVBQUE7RUFFL0I7SUFDSSx5Q0FBYSxFQUFBLEVBQ2hCIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvYWlycGxhbmUvYWlycGxhbmUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQG1lZGlhIChtaW4td2lkdGg6NjUwcHgpIHsgLy8gdGhpcyBydWxlIHdpbGwgb25seSB0cmlnZ2VyIGlmIHNjcmVlbiB3aWR0aCBpcyBhYm92ZSBYcHgsXHJcbiAgICAucGFnZS1jb25maWcge1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OmF1dG87XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OmF1dG87XHJcbiAgICAgICAgd2lkdGg6IHZhcigtLXBhdXNlZm9ybWUtd2lkdGgtbWF4KTtcclxuICAgICAgICAtbW96LWJveC1zaGFkb3c6ICAgIDNweCAzcHggNnB4IDRweCByZ2JhKDUwLCA1MCwgNTAsIDAuNjApO1xyXG4gICAgICAgIC13ZWJraXQtYm94LXNoYWRvdzogM3B4IDNweCA2cHggNHB4IHJnYmEoNTAsIDUwLCA1MCwgMC42MCk7XHJcbiAgICAgICAgYm94LXNoYWRvdzogICAgICAgICAzcHggM3B4IDZweCA0cHggcmdiYSg1MCwgNTAsIDUwLCAwLjYwKTtcclxuICAgIH1cclxuICAgIC5uYXZhaWRzQ29udGFpbmVyIHtcclxuICAgICAgICBwYWRkaW5nOiAwcHggMzBweCAwIDMwcHg7XHJcbiAgICB9XHJcbiAgICAuaGVhZGVyU2VjdGlvbiB7XHJcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAzMHB4O1xyXG4gICAgICAgIHBhZGRpbmctcmlnaHQ6IDMwcHg7XHJcbiAgICB9XHJcbiAgICBpb24tbGlzdC5wYWRkaW5nIHtcclxuICAgICAgICBwYWRkaW5nOiAwcHggNTBweCA1MHB4IDUwcHg7XHJcbiAgICB9XHJcbiAgICBpb24tY29udGVudC5iYWNrZ3JvdW5kIHtcclxuICAgICAgICAtLWJhY2tncm91bmQ6IHZhcigtLXBhdXNlZm9ybS1iYWNrZ3JvdW5kKTtcclxuICAgIH1cclxufVxyXG5cclxuIl19 */"

/***/ }),

/***/ "./src/app/pages/airplane/airplane.page.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/airplane/airplane.page.ts ***!
  \*************************************************/
/*! exports provided: AirplanePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AirplanePage", function() { return AirplanePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/data.service */ "./src/app/services/data.service.ts");
/* harmony import */ var _services_airplane_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/airplane.service */ "./src/app/services/airplane.service.ts");





var AirplanePage = /** @class */ (function () {
    function AirplanePage(navCtrl, dataService, airplaneServices) {
        this.navCtrl = navCtrl;
        this.dataService = dataService;
        this.airplaneServices = airplaneServices;
        this.model = "";
        this.airliner = "";
        this.previousModel = "";
        var saveChanges;
        if (!this.dataService.settings.airplaneId) {
            this.dataService.changeSettingsAirplane("a320");
            saveChanges = true;
        }
        this.airplane = this.airplaneServices.getAirplane(this.dataService.settings.airplaneId);
        this.airliner = this.airplane.airliner;
        this.model = this.airplane.id;
        if (saveChanges) {
            this.dataService.saveSettings();
        }
    }
    AirplanePage.prototype.ngOnInit = function () {
    };
    AirplanePage.prototype.listAirliners = function () {
        return this.airplaneServices.listAirliners();
    };
    AirplanePage.prototype.listAirplanes = function (filterAirliner) {
        return this.airplaneServices.listAirplanes(filterAirliner);
    };
    AirplanePage.prototype.ionViewDidLoad = function () {
    };
    AirplanePage.prototype.ionViewWillLeave = function () {
    };
    AirplanePage.prototype.onChangeHandler = function (event) {
        var idAirplane = event.detail.value;
        if (idAirplane != this.previousModel) {
            this.dataService.changeSettingsAirplane(idAirplane);
            this.dataService.saveSettings();
            this.dataService.notifyChangeSettingsToSubscribers();
            this.previousModel = idAirplane;
        }
    };
    AirplanePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-airplane',
            template: __webpack_require__(/*! ./airplane.page.html */ "./src/app/pages/airplane/airplane.page.html"),
            styles: [__webpack_require__(/*! ./airplane.page.scss */ "./src/app/pages/airplane/airplane.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"],
            _services_airplane_service__WEBPACK_IMPORTED_MODULE_4__["AirplaneService"]])
    ], AirplanePage);
    return AirplanePage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-airplane-airplane-module.js.map