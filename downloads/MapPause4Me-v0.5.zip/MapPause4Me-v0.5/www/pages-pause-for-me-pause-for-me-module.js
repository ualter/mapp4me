(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-pause-for-me-pause-for-me-module"],{

/***/ "./src/app/pages/pause-for-me/pause-for-me.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/pause-for-me/pause-for-me.module.ts ***!
  \***********************************************************/
/*! exports provided: PauseForMePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PauseForMePageModule", function() { return PauseForMePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _pause_for_me_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pause-for-me.page */ "./src/app/pages/pause-for-me/pause-for-me.page.ts");







var routes = [
    {
        path: '',
        component: _pause_for_me_page__WEBPACK_IMPORTED_MODULE_6__["PauseForMePage"]
    }
];
var PauseForMePageModule = /** @class */ (function () {
    function PauseForMePageModule() {
    }
    PauseForMePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_pause_for_me_page__WEBPACK_IMPORTED_MODULE_6__["PauseForMePage"]]
        })
    ], PauseForMePageModule);
    return PauseForMePageModule;
}());



/***/ }),

/***/ "./src/app/pages/pause-for-me/pause-for-me.page.html":
/*!***********************************************************!*\
  !*** ./src/app/pages/pause-for-me/pause-for-me.page.html ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>PauseForMe</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content id=\"pageContent\" class=\"background\">\n  <div class=\"page-config\">\n    <ion-list>\n        <ion-item-group>\n\n          <ion-list-header class=\"listHeader\">\n              <ion-grid class=\"headerSection\">\n                <ion-row class=\"vertical-align-content\">\n                  <ion-col>\n                      <ion-label>\n                          <ion-thumbnail class=\"ion-thumbnailSize\"><img src=\"assets/imgs/altimeter.png\" class=\"imgThumbnailSize\" style=\"width:80px;height:80px;margin-right: 10px;\" ></ion-thumbnail>\n                      </ion-label>\n                  </ion-col>\n                  <ion-col>\n                      <i class=\"fas fa-check-circle\" style=\"color:green;\" [hidden]=\"!altitudeSelected\"></i>\n                      <span [hidden]=\"!altitudeSelected\">&nbsp;</span>\n                      <span style='font-weight:bolder;'>ALTITUDE</span>\n                  </ion-col>\n                  <ion-col>\n                      <ion-button color=\"primary\" fill=\"solid\"  (click)=\"sendAltitude()\">\n                        SEND&nbsp;<ion-icon name=\"paper-plane\"></ion-icon>\n                      </ion-button>\n                  </ion-col>\n                  <!-- size=\"default\" -->\n                </ion-row>\n                <ion-row class=\"vertical-align-content\">\n                  <ion-col><ion-label>&nbsp;</ion-label></ion-col>\n                  <ion-col align-self-center col-25>\n                      <span style=\"font-weight: bold;font-size: 13px;\">{{currentAltitude | number:'3.0-0'}} ft</span>\n                  </ion-col>\n                  <ion-col><ion-label>&nbsp;</ion-label></ion-col>\n                </ion-row>\n              </ion-grid>\n          </ion-list-header>\n          <ion-item lines=\"full\">\n            <ion-range style=\"margin-top: -15px;\" min=\"0\" max=\"40000\" step=\"1\" pin=\"true\" dual-knobs=\"true\" mode=\"ios\" [(ngModel)]=\"altitudeKnobValues\">\n                <ion-label slot=\"start\"><span class=\"labelValueMin\">{{altitudeKnobValues.lower | number:'5.0-0'}}</span></ion-label>\n                <ion-label slot=\"end\"><span class=\"labelValue\">{{altitudeKnobValues.upper | number:'5.0-0'}}</span></ion-label>\n            </ion-range>\n          </ion-item>\n\n          <ion-item-divider lines=\"full\" class=\"config\"></ion-item-divider>\n\n          <ion-list-header class=\"listHeader\">\n              <ion-grid class=\"headerSection\">\n                <ion-row class=\"vertical-align-content\">\n                  <ion-col>\n                      <ion-label>\n                          <ion-thumbnail class=\"ion-thumbnailSize\"><img src=\"assets/imgs/airspeed.png\" class=\"imgThumbnailSize\" style=\"width:80px;height:80px;margin-right: 10px;\" ></ion-thumbnail>\n                      </ion-label>\n                  </ion-col>\n                  <ion-col>\n                      <i class=\"fas fa-check-circle\" style=\"color:green;\" [hidden]=\"!airspeedSelected\"></i>\n                      <span [hidden]=\"!airspeedSelected\">&nbsp;</span>\n                      <span style='font-weight:bolder;'>AIRSPEED</span>\n                  </ion-col>\n                  <ion-col>\n                      <ion-button color=\"primary\" fill=\"solid\" size=\"default\" (click)=\"sendAirspeed()\">\n                          SEND&nbsp;<ion-icon name=\"paper-plane\"></ion-icon>\n                        </ion-button>\n                  </ion-col>\n                </ion-row>\n                <ion-row class=\"vertical-align-content\">\n                    <ion-col><ion-label>&nbsp;</ion-label></ion-col>\n                    <ion-col align-self-center col-25>\n                        <span style=\"font-weight: bold;font-size: 13px;\">{{currentAirspeed | number:'3.0-0'}} kts</span>\n                    </ion-col>\n                    <ion-col><ion-label>&nbsp;</ion-label></ion-col>\n                  </ion-row>\n              </ion-grid>\n          </ion-list-header>\n          <ion-item lines=\"full\">\n            <ion-range style=\"margin-top: -15px;\" min=\"40\" max=\"400\" step=\"1\" pin=\"true\" dual-knobs=\"true\" mode=\"ios\" [(ngModel)]=\"airspeedKnobValues\">\n                <ion-label slot=\"start\"><span class=\"labelValueMin\">{{airspeedKnobValues.lower | number:'3.0-0'}}</span></ion-label>\n                <ion-label slot=\"end\"><span class=\"labelValue\">{{airspeedKnobValues.upper | number:'3.0-0'}}</span></ion-label>\n            </ion-range>\n          </ion-item>\n\n          <ion-item-divider lines=\"full\" class=\"config\"></ion-item-divider>\n\n          <ion-list-header class=\"listHeader\">\n            <ion-grid class=\"headerSection\">\n              <ion-row class=\"vertical-align-content\">\n                <ion-col>\n                    <ion-label>\n                        <ion-thumbnail class=\"ion-thumbnailSize\"><img src=\"assets/imgs/heading.png\" class=\"imgThumbnailSize\" style=\"width:80px;height:80px;margin-right: 10px;\" ></ion-thumbnail>\n                    </ion-label>\n                </ion-col>\n                <ion-col>\n                    <ion-label style='font-weight:bolder;'>NAVAIDs</ion-label>\n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </ion-list-header>\n          <ion-item lines=\"full\">\n            <ion-grid class=\"navaidsContainer\">\n                <!-- AIRPORT -->\n                <ion-row>\n                  <ion-col>\n                      <i class=\"fas fa-check-circle\" style=\"color:green;\" [hidden]=\"!airportSelected\"></i>\n                      Airport:&nbsp;<span class=\"labelValue\">{{airportId}}</span>\n                  </ion-col>\n                </ion-row>\n                <ion-row class=\"vertical-align-content\">\n                  <ion-col size=\"8\" style=\"margin-top: -10px;\">\n                      <ion-label>\n                          <span class=\"labelValueCurrent\">{{currentAirportDist | number:'3.0-0'}} nm</span>&nbsp;\n                          <span style=\"font-size:16px;font-weight: bold\">&#x2264;</span>&nbsp;\n                          <span class=\"labelValue\">{{airportDist | number:'3.0-0'}} nm</span>\n                      </ion-label>\n                  </ion-col>\n                  <ion-col>\n                      <ion-button color=\"primary\" fill=\"solid\" size=\"default\" (click)=\"sendNavaid(airportId,'Airport',airportDist)\">\n                          SEND&nbsp;<ion-icon name=\"paper-plane\"></ion-icon>\n                        </ion-button>\n                  </ion-col>\n                </ion-row>\n                <ion-row>\n                  <ion-col style=\"margin-top:-25px;\">\n                      <ion-range min=\"{{MIN_DIST_NAVAID}}\" max=\"{{MAX_DIST_NAVAID}}\" step=\"{{STEP_NAVAID}}\" mode=\"ios\" [(ngModel)]=\"airportDist\">\n                      </ion-range>\n                  </ion-col>\n                </ion-row>\n  \n                <!-- VOR -->\n                <ion-row>\n                  <ion-col>\n                      <i class=\"fas fa-check-circle\" style=\"color:green;\" [hidden]=\"!vorSelected\"></i>\n                      VOR:&nbsp;<span class=\"labelValue\">{{vorId}}</span>\n                  </ion-col>\n                </ion-row>\n                <ion-row class=\"vertical-align-content\">\n                  <ion-col size=\"8\" style=\"margin-top: -10px;\">\n                      <ion-label>\n                          <span class=\"labelValueCurrent\">{{currentVorDist | number:'3.0-0'}} nm</span>&nbsp;\n                          <span style=\"font-size:16px;font-weight: bold\">&#x2264;</span>&nbsp;\n                          <span class=\"labelValue\">{{vorDist | number:'3.0-0'}} nm</span>\n                      </ion-label>\n                  </ion-col>\n                  <ion-col>\n                      <ion-button color=\"primary\" fill=\"solid\" size=\"default\" (click)=\"sendNavaid(vorId,'VOR',vorDist)\">\n                          SEND&nbsp;<ion-icon name=\"paper-plane\"></ion-icon>\n                        </ion-button>\n                  </ion-col>\n                </ion-row>\n                <ion-row>\n                  <ion-col style=\"margin-top:-25px;\">\n                      <ion-range min=\"{{MIN_DIST_NAVAID}}\" max=\"{{MAX_DIST_NAVAID}}\" step=\"{{STEP_NAVAID}}\" mode=\"ios\" [(ngModel)]=\"vorDist\">\n                      </ion-range>\n                  </ion-col>\n                </ion-row>\n  \n                <!-- NDB -->\n                <ion-row>\n                  <ion-col>\n                      <i class=\"fas fa-check-circle\" style=\"color:green;\" [hidden]=\"!ndbSelected\"></i>\n                      NDB:&nbsp;<span class=\"labelValue\">{{ndbId}}</span>\n                  </ion-col>\n                </ion-row>\n                <ion-row class=\"vertical-align-content\">\n                  <ion-col size=\"8\" style=\"margin-top: -10px;\">\n                      <ion-label>\n                          <span class=\"labelValueCurrent\">{{currentNdbDist | number:'3.0-0'}} nm</span>&nbsp;\n                          <span style=\"font-size:16px;font-weight: bold\">&#x2264;</span>&nbsp;\n                          <span class=\"labelValue\">{{ndbDist | number:'3.0-0'}} nm</span>\n                      </ion-label>\n                  </ion-col>\n                  <ion-col>\n                      <ion-button color=\"primary\" fill=\"solid\" size=\"default\" (click)=\"sendNavaid(ndbId,'NDB',ndbDist)\">\n                          SEND&nbsp;<ion-icon name=\"paper-plane\"></ion-icon>\n                        </ion-button>\n                  </ion-col>\n                </ion-row>\n                <ion-row>\n                  <ion-col style=\"margin-top:-25px;\">\n                      <ion-range min=\"{{MIN_DIST_NAVAID}}\" max=\"{{MAX_DIST_NAVAID}}\" step=\"{{STEP_NAVAID}}\" mode=\"ios\" [(ngModel)]=\"ndbDist\">\n                      </ion-range>\n                  </ion-col>\n                </ion-row>\n  \n                <!-- FIX -->\n                <ion-row>\n                  <ion-col>\n                      <i class=\"fas fa-check-circle\" style=\"color:green;\" [hidden]=\"!fixSelected\"></i>\n                      Fix:&nbsp;<span class=\"labelValue\">{{fixId}}</span>\n                  </ion-col>\n                </ion-row>\n                <ion-row class=\"vertical-align-content\">\n                  <ion-col size=\"8\" style=\"margin-top: -10px;\">\n                      <ion-label>\n                          <span class=\"labelValueCurrent\">{{currentFixDist | number:'3.0-0'}} nm</span>&nbsp;\n                          <span style=\"font-size:16px;font-weight: bold\">&#x2264;</span>&nbsp;\n                          <span class=\"labelValue\">{{fixDist | number:'3.0-0'}} nm</span>\n                      </ion-label>\n                  </ion-col>\n                  <ion-col>\n                      <ion-button color=\"primary\" fill=\"solid\" size=\"default\" (click)=\"sendNavaid(fixId,'FIX',fixDist)\">\n                          SEND&nbsp;<ion-icon name=\"paper-plane\"></ion-icon>\n                        </ion-button>\n                  </ion-col>\n                </ion-row>\n                <ion-row>\n                  <ion-col style=\"margin-top:-25px;\">\n                      <ion-range min=\"{{MIN_DIST_NAVAID}}\" max=\"{{MAX_DIST_NAVAID}}\" step=\"{{STEP_NAVAID}}\" mode=\"ios\" [(ngModel)]=\"fixDist\">\n                      </ion-range>\n                  </ion-col>\n                </ion-row>\n  \n                <!-- DME -->\n                <ion-row>\n                  <ion-col>\n                      <i class=\"fas fa-check-circle\" style=\"color:green;\" [hidden]=\"!dmeSelected\"></i>\n                      DME:&nbsp;<span class=\"labelValue\">{{dmeId}}</span>\n                  </ion-col>\n                </ion-row>\n                <ion-row class=\"vertical-align-content\">\n                  <ion-col size=\"8\" style=\"margin-top: -10px;\">\n                      <ion-label>\n                          <span class=\"labelValueCurrent\">{{currentDmeDist}} nm</span>&nbsp;\n                          <span style=\"font-size:16px;font-weight: bold\">&#x2264;</span>&nbsp;\n                          <span class=\"labelValue\">{{dmeDist | number:'3.0-0'}} nm</span>\n                      </ion-label>\n                  </ion-col>\n                  <ion-col>\n                      <ion-button color=\"primary\" fill=\"solid\" size=\"default\" (click)=\"sendNavaid(dmeId,'DME',dmeDist)\">\n                          SEND&nbsp;<ion-icon name=\"paper-plane\"></ion-icon>\n                        </ion-button>\n                  </ion-col>\n                </ion-row>\n                <ion-row>\n                  <ion-col style=\"margin-top:-25px;\">\n                      <ion-range min=\"{{MIN_DIST_NAVAID}}\" max=\"{{MAX_DIST_NAVAID}}\" step=\"{{STEP_NAVAID}}\" mode=\"ios\" [(ngModel)]=\"dmeDist\">\n                      </ion-range>\n                  </ion-col>\n                </ion-row>\n              </ion-grid>\n          </ion-item>\n\n          <ion-item-divider lines=\"full\" class=\"config\"></ion-item-divider>\n\n          <ion-list-header class=\"listHeader\">\n              <ion-grid class=\"headerSection\">\n                <ion-row class=\"vertical-align-content\">\n                  <ion-col>\n                      <ion-label>\n                          <ion-thumbnail class=\"ion-thumbnailSize\"><img src=\"assets/imgs/{{timeImg}}\" class=\"imgThumbnailSize\" style=\"width:80px;height:80px;margin-right: 10px;\" ></ion-thumbnail>\n                      </ion-label>\n                  </ion-col>\n                  <ion-col>\n                      <i class=\"fas fa-check-circle\" style=\"color:green;\" [hidden]=\"!timeSelected\"></i>\n                      <span [hidden]=\"!timeSelected\">&nbsp;</span>\n                      <span style='font-weight:bolder;'>TIME</span>\n                  </ion-col>\n                  <ion-col>\n                      <ion-button color=\"primary\" fill=\"solid\" size=\"default\" (click)=\"sendTime()\">\n                          SEND&nbsp;&nbsp;<ion-icon name=\"paper-plane\"></ion-icon>\n                        </ion-button>\n                  </ion-col>\n                </ion-row>\n              </ion-grid>\n          </ion-list-header>\n          <ion-item lines=\"full\">\n              <ion-grid>\n                <ion-row class=\"vertical-align-content\">\n                  <ion-col style=\"text-align: center;\" size=\"12\">\n                      <span class=\"labelValueCurrent\">{{currentTime}}</span>\n                  </ion-col>\n                </ion-row>\n                <ion-row class=\"vertical-align-content\">\n                  <ion-col style=\"text-align: center; font-weight: bold;color:black\" size=\"12\">\n                      <span style=\"font-size:16px;font-weight: bold\">&#x3d;</span>\n                  </ion-col>\n                </ion-row>\n                <ion-row class=\"vertical-align-content\" style=\"margin-bottom: 15px;\">\n                  <ion-col style=\"text-align: center; font-weight: bold;color:blue\" size=\"12\">\n                      <ion-datetime display-format=\"HH:mm:ss\" mode=\"ios\" placeholder=\"23:15:00\" [(ngModel)]=\"time\"></ion-datetime>\n                  </ion-col>\n                </ion-row>\n              </ion-grid>\n          </ion-item>\n\n        </ion-item-group>\n    </ion-list>\n    \n  </div>  \n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/pause-for-me/pause-for-me.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/pages/pause-for-me/pause-for-me.page.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@media (min-width: 650px) {\n  .page-config {\n    margin-left: auto;\n    margin-right: auto;\n    width: var(--pauseforme-width-max);\n    box-shadow: 3px 3px 6px 4px rgba(50, 50, 50, 0.6); }\n  .navaidsContainer {\n    padding: 0px 30px 0 30px; }\n  .headerSection {\n    padding-left: 30px;\n    padding-right: 30px; }\n  ion-content.background {\n    --background: var(--pauseform-background); } }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvcGF1c2UtZm9yLW1lL0Q6XFxEZXZlbG9wZXJcXGNvZGVcXGlvbmljXFx4cC1wYXVzZWZvcm1lLXYxL3NyY1xcYXBwXFxwYWdlc1xccGF1c2UtZm9yLW1lXFxwYXVzZS1mb3ItbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0k7SUFDSSxpQkFBZ0I7SUFDaEIsa0JBQWlCO0lBQ2pCLGtDQUFrQztJQUdsQyxpREFBMEQsRUFBQTtFQUU5RDtJQUNJLHdCQUF3QixFQUFBO0VBRTVCO0lBQ0ksa0JBQWtCO0lBQ2xCLG1CQUFtQixFQUFBO0VBRXZCO0lBQ0kseUNBQWEsRUFBQSxFQUNoQiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3BhdXNlLWZvci1tZS9wYXVzZS1mb3ItbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcblxyXG5AbWVkaWEgKG1pbi13aWR0aDo2NTBweCkgeyAvLyB0aGlzIHJ1bGUgd2lsbCBvbmx5IHRyaWdnZXIgaWYgc2NyZWVuIHdpZHRoIGlzIGFib3ZlIFhweCxcclxuICAgIC5wYWdlLWNvbmZpZyB7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6YXV0bztcclxuICAgICAgICBtYXJnaW4tcmlnaHQ6YXV0bztcclxuICAgICAgICB3aWR0aDogdmFyKC0tcGF1c2Vmb3JtZS13aWR0aC1tYXgpO1xyXG4gICAgICAgIC1tb3otYm94LXNoYWRvdzogICAgM3B4IDNweCA2cHggNHB4IHJnYmEoNTAsIDUwLCA1MCwgMC42MCk7XHJcbiAgICAgICAgLXdlYmtpdC1ib3gtc2hhZG93OiAzcHggM3B4IDZweCA0cHggcmdiYSg1MCwgNTAsIDUwLCAwLjYwKTtcclxuICAgICAgICBib3gtc2hhZG93OiAgICAgICAgIDNweCAzcHggNnB4IDRweCByZ2JhKDUwLCA1MCwgNTAsIDAuNjApO1xyXG4gICAgfVxyXG4gICAgLm5hdmFpZHNDb250YWluZXIge1xyXG4gICAgICAgIHBhZGRpbmc6IDBweCAzMHB4IDAgMzBweDtcclxuICAgIH1cclxuICAgIC5oZWFkZXJTZWN0aW9uIHtcclxuICAgICAgICBwYWRkaW5nLWxlZnQ6IDMwcHg7XHJcbiAgICAgICAgcGFkZGluZy1yaWdodDogMzBweDtcclxuICAgIH1cclxuICAgIGlvbi1jb250ZW50LmJhY2tncm91bmQge1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDogdmFyKC0tcGF1c2Vmb3JtLWJhY2tncm91bmQpO1xyXG4gICAgfVxyXG59XHJcblxyXG5cclxuIl19 */"

/***/ }),

/***/ "./src/app/pages/pause-for-me/pause-for-me.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/pause-for-me/pause-for-me.page.ts ***!
  \*********************************************************/
/*! exports provided: PauseForMePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PauseForMePage", function() { return PauseForMePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _services_map_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../services/map.service */ "./src/app/services/map.service.ts");
/* harmony import */ var _services_xp_websocket_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../services/xp-websocket.service */ "./src/app/services/xp-websocket.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../services/utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");






var WS_OPEN = 1;
var PauseForMePage = /** @class */ (function () {
    function PauseForMePage(xpWsSocket, alertCtrl, utils, mapService) {
        var _this = this;
        this.xpWsSocket = xpWsSocket;
        this.alertCtrl = alertCtrl;
        this.utils = utils;
        this.mapService = mapService;
        this.MIN_DIST_NAVAID = 3;
        this.MAX_DIST_NAVAID = 999;
        this.STEP_NAVAID = 1;
        this.ICON_SEPARATOR_NAVAID = "at";
        this.COLOR_ICONS_SELECTION = "warning";
        this.airportId = "LEBL";
        this.vorId = "SLL";
        this.ndbId = "VNV";
        this.fixId = "VIBOK";
        this.dmeId = "BCN";
        this.airportDist = 999;
        this.vorDist = 999;
        this.ndbDist = 999;
        this.fixDist = 999;
        this.dmeDist = 999;
        this.currentAirportDist = 999;
        this.currentVorDist = 999;
        this.currentNdbDist = 999;
        this.currentFixDist = 999;
        this.currentDmeDist = 999;
        this.altitudeKnobValues = {
            upper: 28000,
            lower: 10000
        };
        this.airspeedKnobValues = {
            upper: 320,
            lower: 150
        };
        this.time = "22:15:00";
        this.currentTime = "99:99:99";
        this.currentAltitude = 0;
        this.currentAirspeed = 0;
        this.airportSelected = false;
        this.vorSelected = false;
        this.ndbSelected = false;
        this.fixSelected = false;
        this.dmeSelected = false;
        this.altitudeSelected = false;
        this.airspeedSelected = false;
        this.timeSelected = false;
        if (PauseForMePage_1.reloj == 1) {
            PauseForMePage_1.reloj = 2;
        }
        else {
            PauseForMePage_1.reloj = 1;
        }
        this.timeImg = "time" + PauseForMePage_1.reloj + ".png";
        if (this.xpWsSocket.getLastMessageReceive()) {
            var json = JSON.parse(this.xpWsSocket.getLastMessageReceive());
            if (json && json.airplane && json.airplane.pauseforme) {
                var pauseForMe = json.airplane.pauseforme;
                this.altitudeKnobValues.lower = pauseForMe.altitude.min;
                this.altitudeKnobValues.upper = pauseForMe.altitude.max;
                this.airspeedKnobValues.lower = pauseForMe.speed.min;
                this.airspeedKnobValues.upper = pauseForMe.speed.max;
                this.airportId = pauseForMe.navaid.config.id.airport;
                this.vorId = pauseForMe.navaid.config.id.vor;
                this.fixId = pauseForMe.navaid.config.id.fix;
                this.ndbId = pauseForMe.navaid.config.id.ndb;
                this.dmeId = pauseForMe.navaid.config.id.dme;
                this.airportDist = pauseForMe.navaid.userAirportDistance;
                this.vorDist = pauseForMe.navaid.userVORDistance;
                this.ndbDist = pauseForMe.navaid.userNDBDistance;
                this.fixDist = pauseForMe.navaid.userFixDistance;
                this.dmeDist = pauseForMe.navaid.userDMEDistance;
                this.time = pauseForMe.timePause;
            }
        }
        this.subscription = this.xpWsSocket.messageStream().subscribe(function (json) {
            var json = JSON.parse(json);
            if (json.airplane) {
                _this.currentAltitude = json.airplane.currentAltitude;
                _this.currentAirspeed = json.airplane.airspeed;
                _this.currentAirportDist = json.airplane.pauseforme.navaid.config.distance.airport;
                _this.currentVorDist = json.airplane.pauseforme.navaid.config.distance.vor;
                _this.currentFixDist = json.airplane.pauseforme.navaid.config.distance.fix;
                _this.currentNdbDist = json.airplane.pauseforme.navaid.config.distance.ndb;
                _this.currentDmeDist = json.airplane.pauseforme.navaid.config.distance.dme;
                _this.currentTime = _this.utils.formatCurrentTime(json.airplane.time);
                _this.airportSelected = json.airplane.pauseforme.navaid.config.selected.airport == 1 ? true : false;
                _this.vorSelected = json.airplane.pauseforme.navaid.config.selected.vor == 1 ? true : false;
                _this.ndbSelected = json.airplane.pauseforme.navaid.config.selected.ndb == 1 ? true : false;
                _this.fixSelected = json.airplane.pauseforme.navaid.config.selected.fix == 1 ? true : false;
                _this.dmeSelected = json.airplane.pauseforme.navaid.config.selected.dme == 1 ? true : false;
                _this.altitudeSelected = json.airplane.pauseforme.altitude.selected == 1 ? true : false;
                _this.airspeedSelected = json.airplane.pauseforme.speed.selected == 1 ? true : false;
                _this.timeSelected = json.airplane.pauseforme.timePauseSelected == 1 ? true : false;
                console.log("| etaPauseByNavaIdAirport: " + _this.mapService.etaPauseByNavaIdAirport);
                console.log("| etaPauseByNavaIdVor: " + _this.mapService.etaPauseByNavaIdVor);
                console.log("| etaPauseByNavaIdNdb: " + _this.mapService.etaPauseByNavaIdNdb);
                console.log("| etaPauseByNavaIdFix: " + _this.mapService.etaPauseByNavaIdFix);
                console.log("| etaPauseByNavaIdDme: " + _this.mapService.etaPauseByNavaIdDme);
                console.log("* etaPauseByTime: " + _this.mapService.etaPauseByTime);
                console.log("--------------------------------");
            }
        }, function (error) {
            _this.utils.error('Oops', error);
        });
    }
    PauseForMePage_1 = PauseForMePage;
    PauseForMePage.prototype.ngOnInit = function () {
    };
    PauseForMePage.prototype.ngOnDestroy = function () {
        this.subscription.unsubscribe();
    };
    PauseForMePage.prototype.randomNumber = function (max, min) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
    };
    PauseForMePage.prototype.sendAltitude = function () {
        var msg = "{CONFIG_PAUSE_ALTITUDE}|{CONFIG_PAUSE_ALTITUDE}|" + this.altitudeKnobValues.lower + "|" + this.altitudeKnobValues.upper;
        this.sendMessageXPlane(msg);
    };
    PauseForMePage.prototype.sendAirspeed = function () {
        var msg = "{CONFIG_PAUSE_AIRSPEED}|{CONFIG_PAUSE_AIRSPEED}|" + this.airspeedKnobValues.lower + "|" + this.airspeedKnobValues.upper;
        this.sendMessageXPlane(msg);
    };
    PauseForMePage.prototype.sendTime = function () {
        var msg = "{CONFIG_PAUSE_TIME}|" + this.time;
        this.sendMessageXPlane(msg);
    };
    PauseForMePage.prototype.sendNavaid = function (id, type, dist) {
        var msg = "{CONFIG_PAUSE_NAVAID}|" + id + "|" + type + "|" + dist;
        this.sendMessageXPlane(msg);
    };
    PauseForMePage.prototype.sendMessageXPlane = function (message) {
        console.log(message);
        if (this.xpWsSocket.getWebSocket() && this.xpWsSocket.getWebSocket().readyState == WS_OPEN) {
            this.xpWsSocket.getWebSocket().send(message);
            this.utils.info("Sent to X-Plane: " + message);
        }
        else {
            this.presentAlert({
                header: 'Warning',
                subHeader: 'X-Plane Connection',
                mode: 'ios',
                animated: 'true',
                translucent: ' true',
                message: "\n          You are not connected right now!\n        ",
                buttons: [
                    {
                        text: ' OK ',
                        role: 'cancel',
                        handler: function () {
                        }
                    }
                ]
            });
        }
    };
    PauseForMePage.prototype.presentAlert = function (msgAlert) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create(msgAlert)];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    var PauseForMePage_1;
    PauseForMePage.reloj = 2;
    PauseForMePage = PauseForMePage_1 = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'app-pause-for-me',
            template: __webpack_require__(/*! ./pause-for-me.page.html */ "./src/app/pages/pause-for-me/pause-for-me.page.html"),
            styles: [__webpack_require__(/*! ./pause-for-me.page.scss */ "./src/app/pages/pause-for-me/pause-for-me.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_xp_websocket_service__WEBPACK_IMPORTED_MODULE_2__["XpWebSocketService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_3__["UtilsService"],
            _services_map_service__WEBPACK_IMPORTED_MODULE_1__["MapService"]])
    ], PauseForMePage);
    return PauseForMePage;
}());



/***/ }),

/***/ "./src/app/services/airplane.ts":
/*!**************************************!*\
  !*** ./src/app/services/airplane.ts ***!
  \**************************************/
/*! exports provided: Airplane */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Airplane", function() { return Airplane; });
var PATH_IMG_AIRPLANES = "assets/imgs/airplanes/";
var Airplane = /** @class */ (function () {
    function Airplane(_id) {
        this.id = _id;
    }
    Airplane.pathImg = function () {
        return PATH_IMG_AIRPLANES;
    };
    return Airplane;
}());



/***/ }),

/***/ "./src/app/services/map.service.ts":
/*!*****************************************!*\
  !*** ./src/app/services/map.service.ts ***!
  \*****************************************/
/*! exports provided: MapService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MapService", function() { return MapService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _utils_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils.service */ "./src/app/services/utils.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var DISTANCE_NM = 1852.05;
var SPEED_KTS = 0.514444444444;
var MapService = /** @class */ (function () {
    function MapService(utils) {
        this.utils = utils;
    }
    Object.defineProperty(MapService.prototype, "etaPauseByTime", {
        get: function () {
            return this._etaPauseByTime;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MapService.prototype, "etaPauseByNavaIdAirport", {
        get: function () {
            return this._etaPauseByNavaIdAirport;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MapService.prototype, "etaPauseByNavaIdVor", {
        get: function () {
            return this._etaPauseByNavaIdVor;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MapService.prototype, "etaPauseByNavaIdNdb", {
        get: function () {
            return this._etaPauseByNavaIdNdb;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MapService.prototype, "etaPauseByNavaIdFix", {
        get: function () {
            return this._etaPauseByNavaIdFix;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MapService.prototype, "etaPauseByNavaIdDme", {
        get: function () {
            return this._etaPauseByNavaIdDme;
        },
        enumerable: true,
        configurable: true
    });
    MapService.prototype.calculateETAPauseNavaIdAirport = function (airplaneGroundspeed, distanceAirport) {
        var distance = parseInt(distanceAirport);
        var etaSeconds = ((distance * DISTANCE_NM) / (airplaneGroundspeed * SPEED_KTS));
        this._etaPauseByNavaIdAirport = this.utils.mountTimeFromSeconds(etaSeconds);
    };
    MapService.prototype.calculateETAPauseNavaIdVor = function (airplaneGroundspeed, distanceVor) {
        var distance = parseInt(distanceVor);
        var etaSeconds = ((distance * DISTANCE_NM) / (airplaneGroundspeed * SPEED_KTS));
        this._etaPauseByNavaIdVor = this.utils.mountTimeFromSeconds(etaSeconds);
    };
    MapService.prototype.calculateETAPauseNavaIdFix = function (airplaneGroundspeed, distanceFix) {
        var distance = parseInt(distanceFix);
        var etaSeconds = ((distance * DISTANCE_NM) / (airplaneGroundspeed * SPEED_KTS));
        this._etaPauseByNavaIdFix = this.utils.mountTimeFromSeconds(etaSeconds);
    };
    MapService.prototype.calculateETAPauseNavaIdNdb = function (airplaneGroundspeed, distanceNdb) {
        var distance = parseInt(distanceNdb);
        var etaSeconds = ((distance * DISTANCE_NM) / (airplaneGroundspeed * SPEED_KTS));
        this._etaPauseByNavaIdNdb = this.utils.mountTimeFromSeconds(etaSeconds);
    };
    MapService.prototype.calculateETAPauseNavaIdDme = function (airplaneGroundspeed, distanceDme) {
        var distance = parseInt(distanceDme);
        var etaSeconds = ((distance * DISTANCE_NM) / (airplaneGroundspeed * SPEED_KTS));
        this._etaPauseByNavaIdDme = this.utils.mountTimeFromSeconds(etaSeconds);
    };
    MapService.prototype.calculateETAPauseTime = function (time, timePause) {
        this._etaPauseByTime = this.utils.diffHours(time, timePause);
    };
    MapService.prototype.resetETAPauseNavaIdAirport = function () {
        this._etaPauseByNavaIdAirport = null;
    };
    MapService.prototype.resetETAPauseNavaIdVor = function () {
        this._etaPauseByNavaIdVor = null;
    };
    MapService.prototype.resetETAPauseNavaIdNdb = function () {
        this._etaPauseByNavaIdNdb = null;
    };
    MapService.prototype.resetETAPauseNavaIdFix = function () {
        this._etaPauseByNavaIdFix = null;
    };
    MapService.prototype.resetETAPauseNavaIdDme = function () {
        this._etaPauseByNavaIdDme = null;
    };
    MapService.prototype.resetAllNavaids = function () {
        this.resetETAPauseNavaIdAirport();
        this.resetETAPauseNavaIdVor();
        this.resetETAPauseNavaIdFix();
        this.resetETAPauseNavaIdNdb();
        this.resetETAPauseNavaIdDme();
    };
    MapService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_utils_service__WEBPACK_IMPORTED_MODULE_1__["UtilsService"]])
    ], MapService);
    return MapService;
}());



/***/ }),

/***/ "./src/app/services/utils.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/utils.service.ts ***!
  \*******************************************/
/*! exports provided: LogLevel, UtilsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogLevel", function() { return LogLevel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UtilsService", function() { return UtilsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _airplane__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./airplane */ "./src/app/services/airplane.ts");




var LogLevel;
(function (LogLevel) {
    LogLevel[LogLevel["TRACE"] = 0] = "TRACE";
    LogLevel[LogLevel["DEBUG"] = 1] = "DEBUG";
    LogLevel[LogLevel["INFO"] = 2] = "INFO";
    LogLevel[LogLevel["WARN"] = 3] = "WARN";
    LogLevel[LogLevel["ERROR"] = 4] = "ERROR";
    LogLevel[LogLevel["OFF"] = 5] = "OFF";
})(LogLevel || (LogLevel = {}));
var UtilsService = /** @class */ (function () {
    function UtilsService(platform) {
        this.platform = platform;
        this.PATH_IMG_AIRPLANES = _airplane__WEBPACK_IMPORTED_MODULE_3__["Airplane"].pathImg();
        this.level = LogLevel.DEBUG;
        this.monthNames = [
            "January", "February", "March",
            "April", "May", "June", "July",
            "August", "September", "October",
            "November", "December"
        ];
        this.shortMonthNames = [
            "Jan", "Feb", "Mar",
            "Apr", "May", "Jun", "Jul",
            "Aug", "Sep", "Oct",
            "Nov", "Dec"
        ];
    }
    UtilsService.prototype.formatCurrentTime = function (tm) {
        var h = tm.split(":")[0];
        var m = tm.split(":")[1];
        var s = tm.split(":")[2];
        return this.pad(h, 2) + ":" + this.pad(m, 2) + ":" + this.pad(s, 2);
    };
    UtilsService.prototype.pad = function (num, size) {
        return ('000000000' + num).substr(-size);
    };
    UtilsService.prototype.mountTimeFromSeconds = function (seconds) {
        return new Date(seconds * 1000).toISOString().substr(11, 8);
    };
    UtilsService.prototype.diffHours = function (start, end) {
        start = start.split(":");
        end = end.split(":");
        var startDate = new Date(0, 0, 0, start[0], start[1], start[2]);
        var endDate = new Date(0, 0, 0, end[0], end[1], end[2]);
        var diff = endDate.getTime() - startDate.getTime();
        var hours = Math.floor(diff / 1000 / 60 / 60);
        diff -= hours * 1000 * 60 * 60;
        var minutes = Math.floor(diff / 1000 / 60);
        diff -= minutes * 1000 * 60;
        var seconds = Math.floor(diff / 1000);
        if (hours < 0) {
            hours = hours + 24;
        }
        return (hours <= 9 ? "0" : "") + hours + ":" + (minutes <= 9 ? "0" : "") + minutes + ":" + (seconds <= 9 ? "0" : "") + seconds;
    };
    UtilsService.prototype.convertToMinutes = function (hour) {
        var hor = parseInt(hour.split(":")[0]) * 60;
        var min = parseInt(hour.split(":")[1]);
        return hor + min;
    };
    UtilsService.prototype.isOsPlatform = function () {
        return this.platform.is('ios');
    };
    UtilsService.prototype.isAndroidPlatform = function () {
        return this.platform.is('android');
    };
    UtilsService.prototype.isDesktop = function () {
        return this.platform.is('desktop');
    };
    UtilsService.prototype.isOsOrAndroidPlatform = function () {
        return this.isOsPlatform() || this.isAndroidPlatform();
    };
    UtilsService.prototype.formatDateToday = function () {
        return this.formatDate(new Date());
    };
    UtilsService.prototype.formattedHour = function () {
        var dt = new Date();
        var hor = ("0" + dt.getHours()).slice(-2);
        var min = ("0" + dt.getMinutes()).slice(-2);
        var sec = ("0" + dt.getSeconds()).slice(-2);
        return hor + ":" + min + ":" + sec;
    };
    UtilsService.prototype.formatDate = function (_date) {
        var day = _date.getDate();
        var monthIndex = _date.getMonth();
        var year = _date.getFullYear();
        return year + "/" + this.shortMonthNames[monthIndex] + "/" + day;
    };
    UtilsService.prototype.formatNumber = function (number) {
        return parseInt(number).toString().replace(/\d(?=(\d{3})+$)/g, '$&,');
    };
    UtilsService.prototype.isJsonMessage = function (_message) {
        if (/^[\],:{}\s]*$/.test(_message.replace(/\\["\\\/bfnrtu]/g, '@').
            replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').
            replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {
            return true;
        }
        return false;
    };
    UtilsService.prototype.writeLog = function (msg, logLevel, _object) {
        var logMsg = "[" +
            LogLevel[logLevel] +
            "] " +
            this.formatDateToday() +
            ": " +
            msg;
        if (_object != undefined) {
            logMsg += " ...(cont. next line)...";
        }
        console.log(logMsg);
        if (_object != undefined) {
            console.log(_object);
        }
    };
    UtilsService.prototype.trace = function (msg, _object) {
        if (this.level == LogLevel.TRACE) {
            this.writeLog(msg, LogLevel.TRACE, _object);
        }
    };
    UtilsService.prototype.debug = function (msg, _object) {
        if (this.level <= LogLevel.DEBUG) {
            this.writeLog(msg, LogLevel.DEBUG, _object);
        }
    };
    UtilsService.prototype.info = function (msg, _object) {
        if (this.level <= LogLevel.INFO) {
            this.writeLog(msg, LogLevel.INFO, _object);
        }
    };
    UtilsService.prototype.warn = function (msg, _object) {
        if (this.level <= LogLevel.WARN) {
            this.writeLog(msg, LogLevel.WARN, _object);
        }
    };
    UtilsService.prototype.error = function (msg, _object) {
        if (this.level >= LogLevel.ERROR) {
            this.writeLog(msg, LogLevel.ERROR, _object);
        }
    };
    UtilsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["Platform"]])
    ], UtilsService);
    return UtilsService;
}());



/***/ }),

/***/ "./src/app/services/xp-websocket.service.ts":
/*!**************************************************!*\
  !*** ./src/app/services/xp-websocket.service.ts ***!
  \**************************************************/
/*! exports provided: XpWebSocketService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "XpWebSocketService", function() { return XpWebSocketService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _utils_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./utils.service */ "./src/app/services/utils.service.ts");




var XpWebSocketService = /** @class */ (function () {
    function XpWebSocketService(utils) {
        this.utils = utils;
    }
    XpWebSocketService.prototype.connect = function (url) {
        this.subject = this.create(url);
        return this.subject;
    };
    XpWebSocketService.prototype.create = function (url) {
        var _this = this;
        try {
            this.ws = new WebSocket(url);
        }
        catch (error) {
            console.log(error);
        }
        var observable = rxjs__WEBPACK_IMPORTED_MODULE_2__["Observable"].create(function (obs) {
            _this.ws.onmessage = obs.next.bind(obs);
            _this.ws.onerror = obs.error.bind(obs);
            _this.ws.onclose = obs.complete.bind(obs);
            return _this.ws.close.bind(_this.ws);
        });
        var observer = {
            next: function (data) {
                if (_this.ws.readyState === WebSocket.OPEN) {
                    _this.ws.send(JSON.stringify(data));
                }
                else {
                    _this.utils.info("WS readyState ==" + _this.ws.readyState);
                }
            },
            error: function (data) {
                _this.utils.error("ERROR..:" + data);
                return _this.ws.error;
            },
            complete: function (data) {
                _this.utils.info("CLOSED..:" + data);
            }
        };
        return rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"].create(observer, observable);
    };
    XpWebSocketService.prototype.setLastMessageReceive = function (msg) {
        this.lastMessageReceived = msg;
    };
    XpWebSocketService.prototype.getLastMessageReceive = function () {
        return this.lastMessageReceived;
    };
    XpWebSocketService.prototype.observable = function () {
        return this.subject;
    };
    XpWebSocketService.prototype.messageStream = function () {
        var _this = this;
        return new rxjs__WEBPACK_IMPORTED_MODULE_2__["Observable"](function (observer) {
            setInterval(function () {
                if (_this.getLastMessageReceive()) {
                    observer.next(_this.getLastMessageReceive());
                }
                else {
                    observer.error(" Not available! ");
                }
            }, 1000);
        });
    };
    XpWebSocketService.prototype.getWebSocket = function () {
        return this.ws;
    };
    XpWebSocketService.prototype.disconnect = function () {
        if (this.ws) {
            this.utils.info("Closing connection...");
            this.ws.close();
            this.ws = null;
        }
    };
    XpWebSocketService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_utils_service__WEBPACK_IMPORTED_MODULE_3__["UtilsService"]])
    ], XpWebSocketService);
    return XpWebSocketService;
}());



/***/ })

}]);
//# sourceMappingURL=pages-pause-for-me-pause-for-me-module.js.map